class_name Traffic
extends Node3D
## Other cars that follow the real road geometry and turn at real junctions.

const COLORS := ["#b33a2e", "#2f5d8a", "#e0b43a", "#4a4f55", "#e9e9e4", "#3c7a55", "#8a8f95", "#d8d2c2"]
const SPEEDS := [6.0, 8.0, 10.0, 12.0, 14.0, 17.0, 23.0]
const COUNT := 12

var world: World
var cars: Array = []


func _ready() -> void:
	add_to_group("origin_aware")


func apply_origin() -> void:
	pass


func reset(w: World) -> void:
	world = w
	for t in cars:
		(t.model as Node3D).queue_free()
	cars.clear()
	for i in COUNT:
		var t := {"model": null, "off": true, "f": {}, "i": 0, "u": 0.0, "dir": 1, "speed": 8.0, "pos": Vector2(1e9, 1e9), "a": 0.0}
		cars.append(t)
		_respawn(t, true)


func points() -> Array:
	var out: Array = []
	for t in cars:
		if not t.off:
			var fwd := Vector2(cos(t.a), sin(t.a))
			out.append(t.pos + fwd * 1.25)
			out.append(t.pos - fwd * 1.25)
	return out


func _spot(first: bool) -> Dictionary:
	for _n in 24:
		var ang := randf() * TAU
		var r := (50.0 + randf() * 190.0) if first else (190.0 + randf() * 110.0)
		var q := world.road_at(world.focus + Vector2(cos(ang), sin(ang)) * r, 70.0)
		if not q.is_empty() and float(q.f.w) >= 4.4 and (q.p as Vector2).distance_to(world.focus) > 40.0:
			return q
	return {}


func _place(t: Dictionary) -> void:
	var P: PackedVector2Array = t.f.pts
	var pa := P[t.i]
	var pb := P[t.i + 1]
	var d := pb - pa
	var l := maxf(d.length(), 0.001)
	var f := d / l * float(t.dir)
	var off := float(t.f.w) * (0.18 if int(t.f.ow) != 0 else 0.24)
	t.pos = pa + d * float(t.u) + Vector2(-f.y, f.x) * off     # right-hand traffic: the right of heading f is (-fy, fx)
	t.a = atan2(f.y, f.x)


func _respawn(t: Dictionary, first: bool) -> void:
	var q := _spot(first)
	if q.is_empty():
		t.off = true
		t.pos = Vector2(1e9, 1e9)
		if t.model != null:
			(t.model as Node3D).visible = false
		return
	t.off = false
	t.f = q.f
	t.i = q.i
	t.u = q.t
	t.dir = 1 if int(q.f.ow) != 0 else (1 if randf() < 0.5 else -1)
	t.speed = SPEEDS[mini(int(q.f.rank), SPEEDS.size() - 1)] * (0.75 + randf() * 0.5)
	var col := Color.html(COLORS[randi() % COLORS.size()])
	if t.model == null:
		t.model = CarModel.new(col)
		add_child(t.model)
	(t.model as CarModel).set_color(col)
	(t.model as Node3D).visible = true
	_place(t)


## the car reached vertex vi of its fragment: turn onto a joining road, turn around, or carry on
func _next_seg(t: Dictionary, vi: int) -> bool:
	var P: PackedVector2Array = t.f.pts
	var last := P.size() - 1
	var cands: Array = []
	for e in world.nodes.get(world._nkey(P[vi]), []):
		if e[0] != t.f:
			cands.append(e)
	var at_end: bool = (t.dir > 0 and vi == last) or (t.dir < 0 and vi == 0)
	if not cands.is_empty() and (at_end or randf() < 0.28):
		var opts: Array = []
		for o in cands:
			var f: Dictionary = o[0]
			var n: int = f.pts.size() - 1
			var ow: int = f.ow
			if o[1] < n:
				opts.append([f, o[1], 0.0, 1])
			if o[1] > 0 and ow == 0:
				opts.append([f, o[1] - 1, 1.0, -1])
		if not opts.is_empty():
			var p: Array = opts[randi() % opts.size()]
			t.f = p[0]
			t.i = p[1]
			t.u = p[2]
			t.dir = p[3]
			return true
	if at_end:
		if int(t.f.ow) != 0:
			return false
		t.dir = -t.dir
		t.u = 0.0 if t.dir > 0 else 1.0
		return true
	t.i += 1 if t.dir > 0 else -1
	t.u = 0.0 if t.dir > 0 else 1.0
	return true


func _move(t: Dictionary, dt: float) -> bool:
	var d: float = t.speed * dt
	var guard := 0
	while d > 0.0 and guard < 8:
		guard += 1
		var P: PackedVector2Array = t.f.pts
		var L := maxf(P[t.i].distance_to(P[t.i + 1]), 0.01)
		var rem: float = (1.0 - float(t.u)) * L if t.dir > 0 else float(t.u) * L
		if d < rem:
			t.u += t.dir * d / L
			d = 0.0
			break
		d -= rem
		if not _next_seg(t, t.i + 1 if t.dir > 0 else t.i):
			return false
	_place(t)
	return true


func step(dt: float) -> void:
	for t in cars:
		if t.off:
			if randf() < dt * 0.5:
				_respawn(t, false)
			continue
		if not _move(t, dt) or (t.pos as Vector2).distance_to(world.focus) > 460.0:
			_respawn(t, false)
			continue
		var m: Node3D = t.model
		m.position = world.to3(t.pos, 0.2)
		m.rotation = Vector3(0, -t.a, 0)
		(m as CarModel).animate(t.speed * dt, 0.0)
