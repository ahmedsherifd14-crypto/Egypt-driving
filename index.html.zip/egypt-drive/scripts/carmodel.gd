class_name CarModel
extends Node3D
## A procedural saloon built from lofted cross-sections: a rounded body shell with wheel arches, a glass house you can see the
## interior through, alloy wheels, lamps and mirrors. Original geometry, no brand marks and no number plate.
## The car faces +X, +Z is its right side, +Y is up, wheels turn about Z.
## A licensed model can replace it: put a glTF file at res://cars/car.glb (see README).

const GLB_PATH := "res://cars/car.glb"
const WHEEL_X := [1.28, -1.28]
const WHEEL_R := 0.31
const WHEEL_Z := 0.78
const ARCH_R := 0.385
const BELT := 0.96
const X_FRONT := 2.22
const X_REAR := -2.25
const X_COWL := 0.82
const X_DECK := -1.72
const HALF_W := 0.885
const LEN_MIN := -2.25
const LEN_MAX := 2.22

const M_PAINT := 0
const M_GLASS := 1
const M_DARK := 2
const M_INT := 3
const M_HEAD := 4
const M_TAIL := 5
const M_TRIM := 6
const M_CHROME := 7
const M_DASH := 8
const NMAT := 9

# side profile of the lower shell: [height fraction between floor and top edge, inward offset from the widest point]
const RING_T := [[0.0, 0.30], [0.005, 0.285], [0.07, 0.14], [0.17, 0.05], [0.42, 0.0], [0.66, 0.012], [0.85, 0.06], [0.945, 0.13], [1.0, 0.25]]
const TOP_IN := 0.25
const HOOD_TOP := [Vector2(0.82, 0.955), Vector2(1.2, 0.95), Vector2(1.6, 0.935), Vector2(1.9, 0.905), Vector2(2.08, 0.875), Vector2(2.17, 0.845), Vector2(2.22, 0.80)]
const TRUNK_TOP := [Vector2(-2.25, 0.88), Vector2(-2.21, 0.93), Vector2(-2.12, 0.96), Vector2(-1.9, 0.972), Vector2(-1.72, 0.965)]
const ROOF := [Vector2(-1.72, 0.975), Vector2(-1.52, 1.07), Vector2(-1.3, 1.2), Vector2(-1.0, 1.34), Vector2(-0.7, 1.4), Vector2(-0.3, 1.41), Vector2(0.0, 1.4), Vector2(0.2, 1.34), Vector2(0.5, 1.16), Vector2(0.8, 0.985)]
const SIDE_WIN := [Vector2(-0.2, 0.58), Vector2(-1.0, -0.28), Vector2(-1.4, -1.14)]
const WIND_GLASS := [Vector2(0.2, 0.76), Vector2(-1.52, -0.92)]

static var _shared: Dictionary = {}

var body_mat: StandardMaterial3D
var wheels: Array = []        # pivots: [front-right, front-left, rear-right, rear-left]
var _spin: float = 0.0
var _glb_paint: Array = []


# ------------------------------------------------------------------ mesh accumulator (smooth normals)
class Surf:
	var v := PackedVector3Array()
	var n := PackedVector3Array()
	var idx := PackedInt32Array()

	func add(p: Vector3) -> int:
		v.append(p)
		n.append(Vector3.ZERO)
		return v.size() - 1

	## raw triangle; Godot front faces are clockwise, so the outward normal opposes the right-hand cross product
	func tri(a: int, b: int, c: int) -> void:
		idx.append(a)
		idx.append(b)
		idx.append(c)
		var g := (v[b] - v[a]).cross(v[c] - v[a])
		n[a] -= g
		n[b] -= g
		n[c] -= g

	func tri_hint(a: int, b: int, c: int, hint: Vector3) -> void:
		var g := (v[b] - v[a]).cross(v[c] - v[a])
		if g.dot(hint) > 0.0:
			tri(a, c, b)
		else:
			tri(a, b, c)

	func arrays() -> Array:
		var nn := PackedVector3Array()
		for q in n:
			nn.append(q.normalized() if q.length_squared() > 1e-12 else Vector3.UP)
		var a: Array = []
		a.resize(Mesh.ARRAY_MAX)
		a[Mesh.ARRAY_VERTEX] = v
		a[Mesh.ARRAY_NORMAL] = nn
		a[Mesh.ARRAY_INDEX] = idx
		return a


# ------------------------------------------------------------------ shape functions
## Catmull-Rom through points (x ascending)
static func _smooth(pts: Array, x: float) -> float:
	var n := pts.size()
	if x <= pts[0].x:
		return pts[0].y
	if x >= pts[n - 1].x:
		return pts[n - 1].y
	var i := 0
	while i < n - 2 and x > pts[i + 1].x:
		i += 1
	var t: float = (x - pts[i].x) / (pts[i + 1].x - pts[i].x)
	var p0: float = pts[maxi(i - 1, 0)].y
	var p1: float = pts[i].y
	var p2: float = pts[i + 1].y
	var p3: float = pts[mini(i + 2, n - 1)].y
	return 0.5 * ((2.0 * p1) + (-p0 + p2) * t + (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * t * t + (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * t * t * t)


static func _ybot(x: float) -> float:
	if x > 0.0:
		return 0.22 + 0.13 * smoothstep(1.85, 2.24, x)
	return 0.22 + 0.10 * smoothstep(1.8, 2.26, -x)


static func _width(x: float) -> float:
	if x > 1.5:
		return HALF_W - 0.17 * pow(clampf((x - 1.5) / 0.72, 0.0, 1.0), 2.0)
	if x < -1.8:
		return HALF_W - 0.14 * pow(clampf((-1.8 - x) / 0.45, 0.0, 1.0), 2.0)
	return HALF_W


static func _arch_h(x: float) -> float:
	for cx in WHEEL_X:
		var d := absf(x - float(cx))
		if d <= ARCH_R + 0.0001:
			return WHEEL_R + sqrt(maxf(0.0, ARCH_R * ARCH_R - d * d))
	return 0.0


static func _stations(a: float, b: float, step: float) -> Array:
	var xs: Array = []
	var n := maxi(1, int(ceil((b - a) / step)))
	for k in n + 1:
		xs.append(a + (b - a) * float(k) / float(n))
	for cx in WHEEL_X:
		for k in 17:
			xs.append(float(cx) + ARCH_R * cos(PI * float(k) / 16.0))
		xs.append(float(cx) + ARCH_R + 0.015)
		xs.append(float(cx) - ARCH_R - 0.015)
	xs.sort()
	var out: Array = []
	for x in xs:
		if x < a - 0.0001 or x > b + 0.0001:
			continue
		if out.is_empty() or x - float(out[out.size() - 1]) > 0.012:
			out.append(x)
	return out


static func _in(x: float, ranges: Array) -> bool:
	for r in ranges:
		if x > r.x and x < r.y:
			return true
	return false


static func _mirror(left: Array) -> PackedVector2Array:
	var out := PackedVector2Array()
	for q in left:
		out.append(q)
	for m in range(left.size() - 2, -1, -1):
		out.append(Vector2(-left[m].x, left[m].y))
	return out


static func _clamp_idx(ah: float, yb: float, yt: float, kmax: int) -> int:
	if ah <= 0.0:
		return 0
	var ci := 0
	for k in range(2, kmax + 1):
		if yb + float(RING_T[k - 1][0]) * (yt - yb) < ah:
			ci = k
	return ci


## closed cross-section (bonnet / boot): floor centre, up the left side, over the top, back down the right side
static func _ring_closed(w: float, yb: float, yt: float, crown: float, ah: float) -> PackedVector2Array:
	var h := yt - yb
	var left: Array = [Vector2(0.0, yb)]
	for k in range(1, 10):
		var e: Array = RING_T[k - 1]
		var y: float = yb + float(e[0]) * h
		if ah > 0.0 and k >= 2:
			y = minf(maxf(y, ah), yt)
		left.append(Vector2(-(w - float(e[1])), y))
	left.append(Vector2(-(w - TOP_IN) * 0.5, yt + crown * 0.8))
	left.append(Vector2(0.0, yt + crown))
	return _mirror(left)


## open cross-section through the doors: the shell up to the belt line, a ledge, the inner door and the cabin floor
static func _ring_door(w: float, yb: float, ah: float) -> PackedVector2Array:
	var h := BELT - yb
	var left: Array = [Vector2(0.0, yb)]
	for k in range(1, 8):
		var e: Array = RING_T[k - 1]
		var y: float = yb + float(e[0]) * h
		if ah > 0.0 and k >= 2:
			y = minf(maxf(y, ah), BELT)
		left.append(Vector2(-(w - float(e[1])), y))
	left.append(Vector2(-(w - 0.10), BELT - 0.02))
	left.append(Vector2(-(w - 0.145), BELT))
	left.append(Vector2(-(w - 0.20), BELT))
	left.append(Vector2(-(w - 0.205), BELT - 0.03))
	left.append(Vector2(-(w - 0.21), 0.42))
	left.append(Vector2(-(w - 0.33), 0.36))
	left.append(Vector2(0.0, 0.36))
	return _mirror(left)


static func _cabin_ring(x: float) -> PackedVector2Array:
	var yr := _smooth(ROOF, x)
	var s := clampf((yr - BELT) / 0.40, 0.0, 1.0)
	var wb := HALF_W - 0.145 - 0.075 * clampf((-1.35 - x) / 0.37, 0.0, 1.0)
	var left: Array = [
		Vector2(-wb, BELT),
		Vector2(-(wb - 0.015 * s), BELT + 0.05 * s),
		Vector2(-(wb - 0.10 * s), yr - 0.075 * s),
		Vector2(-(wb - 0.20 * s), yr - 0.012 * s),
		Vector2(-(wb - 0.27 * s), yr + 0.010 * s),
		Vector2(0.0, yr + 0.035 * s)]
	return _mirror(left)


## material of one segment of the shell rings; `ci` = last clamped ring point (arch ceiling) of the two stations
static func _shell_mat(j: int, n: int, ci: int, door: bool) -> int:
	var js := mini(j, n - 2 - j)
	if js == 0:
		return M_DARK
	if ci >= 2 and js >= 1 and js <= ci - 1:
		return M_DARK
	if door:
		if js == 11 or js == 12:
			return M_INT
		if js == 13:
			return M_DASH
	return M_PAINT


# ------------------------------------------------------------------ lofting
## joins consecutive cross-sections (rings of equal point count) with quads; `hard` = point indices that keep a crisp edge
static func _loft(S: Array, xs: Array, rings: Array, mat_of: Callable, hard: Dictionary) -> void:
	var n_st := xs.size()
	var N: int = (rings[0] as PackedVector2Array).size()
	var quads: Array = []
	var score := 0.0
	for i in n_st - 1:
		var r0: PackedVector2Array = rings[i]
		var r1: PackedVector2Array = rings[i + 1]
		for j in N - 1:
			var m: int = mat_of.call(i, j)
			if m < 0:
				continue
			var a := Vector3(xs[i], r0[j].y, r0[j].x)
			var b := Vector3(xs[i + 1], r1[j].y, r1[j].x)
			var d := Vector3(xs[i], r0[j + 1].y, r0[j + 1].x)
			var c := Vector3(xs[i + 1], r1[j + 1].y, r1[j + 1].x)
			var cen := (a + b + c + d) * 0.25
			score += (b - a).cross(d - a).dot(cen - Vector3((float(xs[i]) + float(xs[i + 1])) * 0.5, 0.6, 0.0))
			quads.append([i, j, m])
	var cache := {}
	for q in quads:
		var i: int = q[0]
		var j: int = q[1]
		var m: int = q[2]
		var s: Surf = S[m]
		var ids: Array = []
		for corner in 4:
			var ii := i + (1 if corner == 1 or corner == 2 else 0)
			var jj := j + (1 if corner == 2 or corner == 3 else 0)
			var side := 1 if (corner < 2 and hard.has(jj)) else 0
			var key := ((ii * 128 + jj) * 2 + side) * 16 + m
			if not cache.has(key):
				var p: Vector2 = (rings[ii] as PackedVector2Array)[jj]
				cache[key] = s.add(Vector3(xs[ii], p.y, p.x))
			ids.append(cache[key])
		if score > 0.0:
			s.tri(ids[0], ids[2], ids[1])
			s.tri(ids[0], ids[3], ids[2])
		else:
			s.tri(ids[0], ids[1], ids[2])
			s.tri(ids[0], ids[2], ids[3])


static func _hard_for(n: int, left: Array) -> Dictionary:
	var h := {}
	for k in left:
		h[k] = true
		h[n - 1 - int(k)] = true
	return h


static func _cap(s: Surf, x: float, ring: PackedVector2Array, dir: float) -> void:
	var pts := PackedVector2Array()
	for q in ring:
		if pts.is_empty() or pts[pts.size() - 1].distance_to(q) > 0.002:
			pts.append(q)
	if pts.size() > 2 and pts[0].distance_to(pts[pts.size() - 1]) < 0.002:
		pts.remove_at(pts.size() - 1)
	var tr := Geometry2D.triangulate_polygon(pts)
	if tr.is_empty():
		return
	var base := s.v.size()
	for q in pts:
		s.add(Vector3(x, q.y, q.x))
	for k in range(0, tr.size(), 3):
		s.tri_hint(base + tr[k], base + tr[k + 1], base + tr[k + 2], Vector3(dir, 0, 0))


# ------------------------------------------------------------------ primitives
static func _box(s: Surf, c: Vector3, size: Vector3, rot: Basis = Basis.IDENTITY) -> void:
	var h := size * 0.5
	for ax in 3:
		for sg in [-1.0, 1.0]:
			var nrm := Vector3.ZERO
			nrm[ax] = sg
			var u := Vector3.ZERO
			u[(ax + 1) % 3] = 1.0
			var w := Vector3.ZERO
			w[(ax + 2) % 3] = 1.0
			var base := s.v.size()
			for cu in [-1.0, 1.0]:
				for cv in [-1.0, 1.0]:
					var local: Vector3 = nrm * h + u * (cu * float(h[(ax + 1) % 3])) + w * (cv * float(h[(ax + 2) % 3]))
					s.add(c + rot * local)
			var hint := rot * nrm
			s.tri_hint(base, base + 1, base + 3, hint)
			s.tri_hint(base, base + 3, base + 2, hint)


static func _ell(s: Surf, c: Vector3, r: Vector3, rot: Basis = Basis.IDENTITY, nlat: int = 8, nlon: int = 14) -> void:
	var base := s.v.size()
	for a in nlat + 1:
		var th := PI * float(a) / float(nlat)
		for b in nlon:
			var ph := TAU * float(b) / float(nlon)
			s.add(c + rot * (Vector3(sin(th) * cos(ph), cos(th), sin(th) * sin(ph)) * r))
	for a in nlat:
		for b in nlon:
			var i0 := base + a * nlon + b
			var i1 := base + a * nlon + (b + 1) % nlon
			var i2 := base + (a + 1) * nlon + b
			var i3 := base + (a + 1) * nlon + (b + 1) % nlon
			var hint := s.v[i0] + s.v[i3] - c * 2.0
			s.tri_hint(i0, i2, i3, hint)
			s.tri_hint(i0, i3, i1, hint)


static func _torus(s: Surf, c: Vector3, big: float, small: float, rot: Basis, nu: int = 20, nv: int = 8) -> void:
	var base := s.v.size()
	for a in nu:
		var ang := TAU * float(a) / float(nu)
		var radial := Vector3(cos(ang), sin(ang), 0.0)
		for b in nv:
			var ph := TAU * float(b) / float(nv)
			s.add(c + rot * (radial * (big + small * cos(ph)) + Vector3(0, 0, small * sin(ph))))
	for a in nu:
		for b in nv:
			var i0 := base + a * nv + b
			var i1 := base + a * nv + (b + 1) % nv
			var i2 := base + ((a + 1) % nu) * nv + b
			var i3 := base + ((a + 1) % nu) * nv + (b + 1) % nv
			var ang2 := TAU * (float(a) + 0.5) / float(nu)
			var hint := s.v[i0] - (c + rot * (Vector3(cos(ang2), sin(ang2), 0.0) * big))
			s.tri_hint(i0, i2, i3, hint)
			s.tri_hint(i0, i3, i1, hint)


## thin open cylinder along the local Y axis
static func _cyl(s: Surf, c: Vector3, r: float, h: float, rot: Basis, seg: int = 6) -> void:
	var base := s.v.size()
	for k in seg:
		var ph := TAU * float(k) / float(seg)
		s.add(c + rot * Vector3(r * cos(ph), -h * 0.5, r * sin(ph)))
		s.add(c + rot * Vector3(r * cos(ph), h * 0.5, r * sin(ph)))
	for k in seg:
		var i0 := base + k * 2
		var i1 := base + ((k + 1) % seg) * 2
		var hint := s.v[i0] - (c + rot * Vector3(0, -h * 0.5, 0))
		s.tri_hint(i0, i0 + 1, i1 + 1, hint)
		s.tri_hint(i0, i1 + 1, i1, hint)


## surface of revolution about the Z axis; profile points are (radius, z). The hint centre says which side is "outside".
static func _lathe(s: Surf, prof: Array, segs: int, hint_r: float, hint_z: float) -> void:
	var base := s.v.size()
	for p in prof:
		for k in segs:
			var ph := TAU * float(k) / float(segs)
			s.add(Vector3(p.x * cos(ph), p.x * sin(ph), p.y))
	var np := prof.size()
	for a in np - 1:
		for k in segs:
			var k1 := (k + 1) % segs
			var i0 := base + a * segs + k
			var i1 := base + a * segs + k1
			var i2 := base + (a + 1) * segs + k
			var i3 := base + (a + 1) * segs + k1
			var ph := TAU * (float(k) + 0.5) / float(segs)
			var hint := s.v[i0] - Vector3(hint_r * cos(ph), hint_r * sin(ph), hint_z)
			s.tri_hint(i0, i2, i3, hint)
			s.tri_hint(i0, i3, i1, hint)


# ------------------------------------------------------------------ building the shared meshes
static func _to_mesh(S: Array, ids_out: Array) -> ArrayMesh:
	var m := ArrayMesh.new()
	for k in S.size():
		var s: Surf = S[k]
		if s.idx.size() > 0:
			m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, s.arrays())
			ids_out.append(k)
	return m


static func _build_body() -> Array:
	var S: Array = []
	for _i in NMAT:
		S.append(Surf.new())
	# ---- bonnet and front end
	var xs_h := _stations(X_COWL, X_FRONT, 0.09)
	var rings_h: Array = []
	var ci_h: Array = []
	for x in xs_h:
		var yb := _ybot(x)
		var yt := _smooth(HOOD_TOP, x)
		var ah := _arch_h(x)
		rings_h.append(_ring_closed(_width(x), yb, yt, 0.028, ah))
		ci_h.append(_clamp_idx(ah, yb, yt, 9))
	var n_h: int = (rings_h[0] as PackedVector2Array).size()
	_loft(S, xs_h, rings_h, func(i: int, j: int) -> int: return CarModel._shell_mat(j, n_h, maxi(ci_h[i], ci_h[i + 1]), false), _hard_for(n_h, [1, 2]))
	_cap(S[M_PAINT], X_FRONT, rings_h[rings_h.size() - 1], 1.0)
	_cap(S[M_DASH], X_COWL, rings_h[0], -1.0)
	# ---- doors (open shell)
	var xs_d := _stations(X_DECK, X_COWL, 0.1)
	var rings_d: Array = []
	var ci_d: Array = []
	for x in xs_d:
		var yb := _ybot(x)
		var ah := _arch_h(x)
		rings_d.append(_ring_door(_width(x), yb, ah))
		ci_d.append(_clamp_idx(ah, yb, BELT, 7))
	var n_d: int = (rings_d[0] as PackedVector2Array).size()
	_loft(S, xs_d, rings_d, func(i: int, j: int) -> int: return CarModel._shell_mat(j, n_d, maxi(ci_d[i], ci_d[i + 1]), true), _hard_for(n_d, [1, 2, 9, 10, 11, 13]))
	# ---- boot and rear end
	var xs_t := _stations(X_REAR, X_DECK, 0.06)
	var rings_t: Array = []
	for x in xs_t:
		rings_t.append(_ring_closed(_width(x), _ybot(x), _smooth(TRUNK_TOP, x), 0.028, 0.0))
	var n_t: int = (rings_t[0] as PackedVector2Array).size()
	_loft(S, xs_t, rings_t, func(i: int, j: int) -> int: return CarModel._shell_mat(j, n_t, 0, false), _hard_for(n_t, [1, 2]))
	_cap(S[M_PAINT], X_REAR, rings_t[0], -1.0)
	_cap(S[M_INT], X_DECK, rings_t[rings_t.size() - 1], 1.0)
	# ---- glass house
	var xs_c: Array = [0.8, 0.76, 0.58, 0.4, 0.2, 0.0, -0.2, -0.28, -0.5, -0.7, -0.92, -1.0, -1.14, -1.2, -1.4, -1.52, -1.72]
	xs_c.reverse()
	var rings_c: Array = []
	for x in xs_c:
		rings_c.append(_cabin_ring(x))
	var cab_mat := func(i: int, j: int) -> int:
		var xm: float = (float(xs_c[i]) + float(xs_c[i + 1])) * 0.5
		var js := mini(j, 9 - j)
		if js == 1 and CarModel._in(xm, CarModel.SIDE_WIN):
			return CarModel.M_GLASS
		if js == 4 and CarModel._in(xm, CarModel.WIND_GLASS):
			return CarModel.M_GLASS
		return CarModel.M_PAINT
	_loft(S, xs_c, rings_c, cab_mat, {})
	# headliner: the inside of the roof, a little lower
	var rings_l: Array = []
	for r in rings_c:
		var q := PackedVector2Array()
		for p in (r as PackedVector2Array):
			q.append(Vector2(p.x * 0.96, p.y - 0.035))
		rings_l.append(q)
	_loft(S, xs_c, rings_l, func(_i: int, j: int) -> int: return CarModel.M_INT if (mini(j, 9 - j) >= 3) else -1, {})
	_interior(S)
	_details(S)
	return S


static func _interior(S: Array) -> void:
	var seat: Surf = S[M_INT]
	var dash: Surf = S[M_DASH]
	var lean := Basis(Vector3.BACK, 0.2)       # seat backs lean rearwards (+X is forward, so tip the top toward -X)
	_box(dash, Vector3(0.64, 0.74, 0.0), Vector3(0.36, 0.30, 1.42))
	_box(dash, Vector3(0.50, 0.90, -0.34), Vector3(0.26, 0.10, 0.56))
	_box(dash, Vector3(0.26, 0.47, 0.0), Vector3(0.80, 0.18, 0.26))
	_torus(dash, Vector3(0.34, 0.86, -0.34), 0.17, 0.016, Basis(Vector3.UP, PI * 0.5).rotated(Vector3.BACK, -0.45))
	for sz in [-0.36, 0.36]:
		_box(seat, Vector3(0.18, 0.45, sz), Vector3(0.50, 0.12, 0.50))
		_box(seat, Vector3(-0.10, 0.76, sz), Vector3(0.12, 0.66, 0.48), lean)
		_box(seat, Vector3(-0.19, 1.14, sz), Vector3(0.09, 0.22, 0.26), lean)
	_box(seat, Vector3(-0.82, 0.45, 0.0), Vector3(0.52, 0.12, 1.36))
	_box(seat, Vector3(-1.10, 0.76, 0.0), Vector3(0.12, 0.66, 1.36), lean)
	for sz in [-0.40, 0.40]:
		_box(seat, Vector3(-1.19, 1.13, sz), Vector3(0.09, 0.2, 0.28), lean)


static func _details(S: Array) -> void:
	var head: Surf = S[M_HEAD]
	var tail: Surf = S[M_TAIL]
	var trim: Surf = S[M_TRIM]
	var chrome: Surf = S[M_CHROME]
	var paint: Surf = S[M_PAINT]
	var glass: Surf = S[M_GLASS]
	for sg in [-1.0, 1.0]:
		var yaw_f := Basis(Vector3.UP, -0.42 * sg)
		_ell(head, Vector3(2.19, 0.765, 0.52 * sg), Vector3(0.05, 0.058, 0.17), yaw_f)
		# rear lamp: flat decal on the rear face, wrapping the corner
		_cap(tail, X_REAR - 0.003, PackedVector2Array([Vector2(0.25 * sg, 0.855), Vector2(0.60 * sg, 0.855), Vector2(0.69 * sg, 0.74), Vector2(0.25 * sg, 0.74)]), -1.0)
		_ell(trim, Vector3(2.17, 0.43, 0.62 * sg), Vector3(0.05, 0.05, 0.075))
		_ell(chrome, Vector3(2.19, 0.43, 0.62 * sg), Vector3(0.03, 0.035, 0.05))
		# door shut lines and handles
		_box(trim, Vector3(0.60, 0.65, 0.887 * sg), Vector3(0.008, 0.62, 0.006))
		_box(trim, Vector3(-0.30, 0.65, 0.887 * sg), Vector3(0.008, 0.62, 0.006))
		_box(trim, Vector3(-1.04, 0.82, 0.887 * sg), Vector3(0.008, 0.28, 0.006))
		_box(chrome, Vector3(0.20, 0.86, 0.893 * sg), Vector3(0.14, 0.018, 0.014))
		_box(chrome, Vector3(-0.60, 0.86, 0.893 * sg), Vector3(0.14, 0.018, 0.014))
		_box(trim, Vector3(0.0, 0.53, 0.891 * sg), Vector3(1.62, 0.05, 0.012))
		# mirrors
		_ell(paint, Vector3(0.58, 1.0, 0.95 * sg), Vector3(0.075, 0.062, 0.12), Basis(Vector3.UP, -0.2 * sg))
		_box(trim, Vector3(0.62, 0.97, 0.86 * sg), Vector3(0.06, 0.03, 0.10))
		_box(glass, Vector3(0.52, 1.0, 0.95 * sg), Vector3(0.01, 0.05, 0.09))
	# front: trapezoid grille with slats, lower intake, bumper lip (flush decals on the flat front face)
	_cap(trim, X_FRONT + 0.004, PackedVector2Array([Vector2(-0.36, 0.745), Vector2(0.36, 0.745), Vector2(0.30, 0.585), Vector2(-0.30, 0.585)]), 1.0)
	_box(chrome, Vector3(X_FRONT + 0.008, 0.752, 0.0), Vector3(0.016, 0.016, 0.76))
	_box(chrome, Vector3(X_FRONT + 0.008, 0.578, 0.0), Vector3(0.016, 0.016, 0.64))
	for gy in [0.625, 0.665, 0.705]:
		var hw := 0.30 + 0.06 * (float(gy) - 0.585) / 0.16
		_box(chrome, Vector3(X_FRONT + 0.007, gy, 0.0), Vector3(0.012, 0.009, hw * 2.0))
	_cap(trim, X_FRONT + 0.004, PackedVector2Array([Vector2(-0.47, 0.525), Vector2(0.47, 0.525), Vector2(0.40, 0.405), Vector2(-0.40, 0.405)]), 1.0)
	_box(trim, Vector3(2.15, 0.355, 0.0), Vector3(0.08, 0.04, 1.2))
	# rear: bumper strip, boot-lid line, reflector bar
	_box(trim, Vector3(-2.235, 0.40, 0.0), Vector3(0.04, 0.075, 1.1))
	_box(trim, Vector3(-2.20, 0.66, 0.0), Vector3(0.04, 0.02, 0.9))
	# antenna
	_cyl(trim, Vector3(-1.02, 1.56, -0.24), 0.0045, 0.34, Basis(Vector3.BACK, 0.42))


static func _build_wheel(side: float) -> Array:
	var S: Array = [Surf.new(), Surf.new(), Surf.new()]     # tyre, rim, brake
	_lathe(S[0], [Vector2(0.205, -0.09), Vector2(0.26, -0.1), Vector2(0.30, -0.085), Vector2(0.31, -0.05), Vector2(0.312, 0.0),
		Vector2(0.31, 0.05), Vector2(0.30, 0.085), Vector2(0.26, 0.1), Vector2(0.205, 0.09)], 28, 0.26, 0.0)
	var rim: Surf = S[1]
	_lathe(rim, [Vector2(0.19, 0.045 * side), Vector2(0.205, 0.062 * side), Vector2(0.206, 0.092 * side)], 28, 0.1, 0.0)
	for k in 5:
		var ang := TAU * float(k) / 5.0
		_box(rim, Vector3(0.112 * cos(ang), 0.112 * sin(ang), 0.05 * side), Vector3(0.16, 0.052, 0.022), Basis(Vector3.BACK, ang))
	_lathe(rim, [Vector2(0.0, 0.07 * side), Vector2(0.05, 0.066 * side), Vector2(0.055, 0.052 * side)], 14, 0.0, 0.0)
	_lathe(S[2], [Vector2(0.0, 0.028 * side), Vector2(0.19, 0.036 * side)], 24, 0.0, 0.0)
	_lathe(S[2], [Vector2(0.05, 0.0), Vector2(0.17, 0.0)], 24, 0.0, 0.0)
	return S


static func _materials() -> Array:
	var out: Array = []
	out.resize(NMAT)
	var glass := StandardMaterial3D.new()
	glass.albedo_color = Color(0.07, 0.12, 0.17, 0.55)
	glass.metallic = 0.4
	glass.roughness = 0.05
	glass.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	glass.cull_mode = BaseMaterial3D.CULL_DISABLED
	out[M_GLASS] = glass
	out[M_DARK] = _mat(Color(0.035, 0.035, 0.04), 0.0, 0.7)
	out[M_INT] = _mat(Color(0.42, 0.44, 0.46), 0.0, 0.85)
	out[M_DASH] = _mat(Color(0.10, 0.10, 0.11), 0.0, 0.7)
	var head := _mat(Color(0.86, 0.89, 0.92), 0.5, 0.08)
	head.emission_enabled = true
	head.emission = Color(0.9, 0.93, 1.0)
	head.emission_energy_multiplier = 0.3
	out[M_HEAD] = head
	var tail := _mat(Color(0.55, 0.03, 0.03), 0.2, 0.2)
	tail.emission_enabled = true
	tail.emission = Color(0.9, 0.05, 0.05)
	tail.emission_energy_multiplier = 0.35
	out[M_TAIL] = tail
	out[M_TRIM] = _mat(Color(0.06, 0.06, 0.07), 0.0, 0.5)
	out[M_CHROME] = _mat(Color(0.8, 0.82, 0.85), 1.0, 0.2)
	return out


static func _mat(c: Color, metallic: float, rough: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.metallic = metallic
	m.roughness = rough
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	return m


static func _get_shared() -> Dictionary:
	if _shared.is_empty():
		var ids: Array = []
		_shared["body"] = _to_mesh(_build_body(), ids)
		_shared["ids"] = ids
		_shared["mats"] = _materials()
		var wm: Array = []
		var wids: Array = []
		for side in [1.0, -1.0]:
			wm.append(_to_mesh(_build_wheel(side), wids))
		_shared["wheel"] = wm
		var wmat: Array = [_mat(Color(0.025, 0.025, 0.03), 0.0, 0.85), _mat(Color(0.78, 0.8, 0.83), 0.9, 0.25), _mat(Color(0.14, 0.14, 0.15), 0.6, 0.5)]
		_shared["wmat"] = wmat
	return _shared


# ------------------------------------------------------------------ instance
func _init(color: Color = Color(0.85, 0.87, 0.9)) -> void:
	if ResourceLoader.exists(GLB_PATH) and _init_glb(color):
		return
	var s := _get_shared()
	body_mat = _mat(color, 0.35, 0.28)
	body_mat.clearcoat_enabled = true
	body_mat.clearcoat = 0.7
	body_mat.clearcoat_roughness = 0.1
	var mi := MeshInstance3D.new()
	mi.mesh = s["body"]
	var ids: Array = s["ids"]
	var mats: Array = s["mats"]
	for k in ids.size():
		mi.set_surface_override_material(k, body_mat if ids[k] == M_PAINT else mats[ids[k]])
	add_child(mi)
	var wmat: Array = s["wmat"]
	var wm: Array = s["wheel"]
	for cx in WHEEL_X:
		for sz in [1.0, -1.0]:
			var pivot := Node3D.new()
			pivot.position = Vector3(cx, WHEEL_R, sz * WHEEL_Z)
			var w := MeshInstance3D.new()
			w.mesh = wm[0 if sz > 0.0 else 1]
			for k in 3:
				w.set_surface_override_material(k, wmat[k])
			pivot.add_child(w)
			add_child(pivot)
			wheels.append(pivot)


func set_color(c: Color) -> void:
	if body_mat != null:
		body_mat.albedo_color = c
	for m in _glb_paint:
		(m as StandardMaterial3D).albedo_color = c


## roll the wheels by `dist` metres; steer the front pair by `steer` radians
func animate(dist: float, steer: float) -> void:
	_spin += dist / WHEEL_R
	for i in wheels.size():
		var w: Node3D = wheels[i]
		w.rotation = Vector3(0, 0, 0)
		if i < 2:
			w.rotation.y = -steer
		w.rotate_object_local(Vector3(0, 0, 1), -_spin)


# ------------------------------------------------------------------ optional licensed model (res://cars/car.glb)
func _init_glb(color: Color) -> bool:
	var ps := load(GLB_PATH) as PackedScene
	if ps == null:
		return false
	var inst := ps.instantiate() as Node3D
	if inst == null:
		return false
	var holder := Node3D.new()
	holder.add_child(inst)
	add_child(holder)
	var box := _tree_aabb(inst, Transform3D.IDENTITY)
	if box.size.length() < 0.01:
		holder.queue_free()
		return false
	if box.size.z > box.size.x:
		holder.rotation.y = PI * 0.5          # glTF cars usually face +Z; this game faces +X
		box = Transform3D(Basis(Vector3.UP, PI * 0.5), Vector3.ZERO) * box
	var f := 4.45 / maxf(box.size.x, 0.01)
	holder.scale = Vector3.ONE * f
	holder.position = Vector3(-(box.position.x + box.size.x * 0.5) * f, -box.position.y * f, -(box.position.z + box.size.z * 0.5) * f)
	_recolor(inst, color)
	return true


func _tree_aabb(n: Node, parent_t: Transform3D) -> AABB:
	var t := parent_t
	if n is Node3D:
		t = parent_t * (n as Node3D).transform
	var out := AABB()
	var have := false
	if n is MeshInstance3D and (n as MeshInstance3D).mesh != null:
		out = t * (n as MeshInstance3D).mesh.get_aabb()
		have = true
	for ch in n.get_children():
		var b := _tree_aabb(ch, t)
		if b.size.length() > 0.0:
			out = b if not have else out.merge(b)
			have = true
	return out


func _recolor(n: Node, color: Color) -> void:
	if n is MeshInstance3D:
		var mi := n as MeshInstance3D
		for k in mi.mesh.get_surface_count():
			var m := mi.mesh.surface_get_material(k)
			if m is StandardMaterial3D:
				var nm := str(m.resource_name).to_lower()
				if nm.contains("body") or nm.contains("paint") or nm.contains("carpaint"):
					var d := (m as StandardMaterial3D).duplicate() as StandardMaterial3D
					d.albedo_color = color
					mi.set_surface_override_material(k, d)
					_glb_paint.append(d)
	for ch in n.get_children():
		_recolor(ch, color)
