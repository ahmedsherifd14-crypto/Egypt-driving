extends Node3D
## Egypt Drive: drive a car on the real streets of Egypt (OpenStreetMap), pick any destination on a 3D model of Egypt.

const COLORS := ["#d8dee3", "#b33a2e", "#2f5d8a", "#2d3338", "#e0b43a", "#3c7a55"]

var world: World
var car: Car
var traffic: Traffic
var nav: Nav
var hud: Hud
var map_view: EgyptMap
var cam: Camera3D
var sun: DirectionalLight3D
var fade: ColorRect
var game_nodes: Array = []

var started: bool = false
var running: bool = false
var busy: bool = false          # travelling (teleport) in progress
var prepared: bool = false
var view_mode: int = 0
var color_i: int = 0
var cam_a: float = -PI / 2.0
var drift_pts: float = 0.0
var score: float = 0.0
var area_name: String = "دمياط الجديدة"
var _area_t: float = 0.0
var _area_pos := Vector2(1e9, 1e9)
var _area_busy: bool = false
var _loc_t: float = 0.0
var _hud_t: float = 0.0
var _prepare_gen: int = 0
var _test_obj: RefCounted


func _ready() -> void:
	_build_environment()
	world = World.new()
	add_child(world)
	car = Car.new()
	add_child(car)
	traffic = Traffic.new()
	add_child(traffic)
	nav = Nav.new()
	nav.world = world
	add_child(nav)
	nav.arrived.connect(func(n): hud.show_arrive(n))
	nav.rerouted.connect(func(): hud.toast("اتحسب طريق جديد"))
	game_nodes = [world, car, traffic, nav, sun]
	cam = Camera3D.new()
	cam.fov = 68.0
	cam.near = 0.2
	cam.far = 3200.0
	add_child(cam)
	cam.make_current()
	hud = Hud.new()
	add_child(hud)
	hud.start_pressed.connect(_on_start)
	hud.retry_pressed.connect(_prepare_start)
	hud.map_pressed.connect(open_map)
	hud.reset_pressed.connect(_reset_to_road)
	hud.view_pressed.connect(func(): view_mode ^= 1)
	hud.color_pressed.connect(_next_color)
	hud.nav_cancel_pressed.connect(func():
		nav.clear()
		hud.toast("اتلغت الوجهة"))
	hud.jump_pressed.connect(func(): _jump_along(5000.0))
	hud.jump_near_pressed.connect(_jump_near)
	hud.voice_toggled.connect(func(on):
		nav.voice = on
		if on:
			nav.speak("تم تشغيل التوجيه الصوتي"))
	map_view = EgyptMap.new()
	map_view.visible = false
	add_child(map_view)
	map_view.closed.connect(close_map)
	map_view.drive_requested.connect(_on_drive_requested)
	fade = ColorRect.new()
	fade.color = Color(0, 0, 0, 1)
	fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fade.modulate.a = 0.0
	var fl := CanvasLayer.new()
	fl.layer = 20
	fl.add_child(fade)
	add_child(fl)
	traffic.world = world
	await get_tree().process_frame
	_prepare_start()
	if Cfg.autotest != "":
		var t := load("res://test/%s.gd" % Cfg.autotest)
		if t != null:
			_test_obj = t.new()
			_test_obj.run(self)


func _build_environment() -> void:
	var env := Environment.new()
	var sky := Sky.new()
	var sm := ProceduralSkyMaterial.new()
	sm.sky_top_color = Color(0.32, 0.55, 0.88)
	sm.sky_horizon_color = Color(0.72, 0.84, 0.93)
	sm.ground_horizon_color = Color(0.72, 0.84, 0.93)
	sm.ground_bottom_color = Color(0.6, 0.66, 0.62)
	sm.sun_angle_max = 25.0
	sky.sky_material = sm
	env.sky = sky
	env.background_mode = Environment.BG_SKY
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR   # the sky's own light is far too blue on the ground
	env.ambient_light_color = Color(0.8, 0.83, 0.9)
	env.ambient_light_energy = 0.45
	env.tonemap_mode = Environment.TONE_MAPPER_LINEAR
	env.tonemap_exposure = 1.0
	env.fog_enabled = true
	env.fog_light_color = Color(0.74, 0.85, 0.93)
	env.fog_density = 0.00055
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -35, 0)
	sun.light_energy = 0.85
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 220.0
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	sun.shadow_bias = 0.06
	add_child(sun)


# ------------------------------------------------------------------ start
func _prepare_start() -> void:
	_prepare_gen += 1
	var gen := _prepare_gen
	prepared = false
	started = false
	running = false
	hud.show_start("بدوّر على مستشفى كابيتال كير في دمياط الجديدة…", false, false)
	var lat: float = Cfg.start.lat
	var lon: float = Cfg.start.lon
	var found := false
	for q in ["مستشفى كابيتال كير دمياط الجديدة", "Capital Care Hospital New Damietta"]:
		var r: Array = await Net.geocode(q, 1)
		if gen != _prepare_gen:
			return
		if r.size() > 0 and Geo.haversine(r[0].lat, r[0].lon, Cfg.start.lat, Cfg.start.lon) < 20000.0:
			lat = r[0].lat
			lon = r[0].lon
			found = true
			break
	Cfg.start.found = found
	world.new_trip(lat, lon)
	car.place(Vector2.ZERO, -PI / 2.0)
	cam_a = car.a
	hud.show_start("بحمّل شوارع دمياط الجديدة الحقيقية…", false, false)
	var t0 := Time.get_ticks_msec()
	var ok := false
	while Time.get_ticks_msec() - t0 < 60000:
		if gen != _prepare_gen:
			return
		world.force_stream()
		if world.is_ready():
			ok = true
			break
		hud.start_msg.text = "بحمّل شوارع دمياط الجديدة الحقيقية… (%s/%s)" % [Geo.ar_num(str(maxi(0, world.total - world.pending))), Geo.ar_num(str(world.total))]
		if Time.get_ticks_msec() - t0 > 14000 and Net.last_err != "" and Time.get_ticks_msec() - Net.last_ok_ms > 12000:
			break
		await get_tree().create_timer(0.2).timeout
	if not ok:
		hud.show_start("معرفتش أوصل لسيرفرات الخرائط (OpenStreetMap). اتأكد إن النت شغال وجرّب تاني. (%s)" % (Net.last_err if Net.last_err != "" else "بدون رد"), false, true, true)
		return
	var snapped := _snap_to_road(700.0, false)
	traffic.reset(world)
	prepared = true
	hud.show_start(("لقيت المكان على الخريطة. " if found else "مش لاقي المستشفى بالاسم في الخريطة، فبدأت من وسط دمياط الجديدة التقريبي. ") + ("العربية جاهزة على أقرب شارع حقيقي." if snapped else "مفيش شارع قريب، هتبدأ في مكان مفتوح."), true, false)
	_update_loc(true)


func _on_start() -> void:
	if not prepared:
		return
	hud.hide_start()
	started = true
	running = true
	hud.toast(world.road_label(car.cur_road.f) if not car.cur_road.is_empty() else area_name)


## put the car on the nearest real road, pointing along it
func _snap_to_road(maxd: float, keep_heading: bool) -> bool:
	var q := world.road_at(car.pos, maxd)
	if q.is_empty():
		return false
	var P: PackedVector2Array = q.f.pts
	var d := (P[q.i + 1] - P[q.i]).normalized()
	if int(q.f.ow) == 0 and car.forward().dot(d) < 0.0:
		d = -d
	var off: float = float(q.f.w) * (0.12 if int(q.f.ow) != 0 else 0.2)
	car.pos = q.p + Vector2(-d.y, d.x) * off
	car.vel = Vector2.ZERO
	car.spd = 0.0
	car.steer = 0.0
	if not keep_heading:
		car.a = atan2(d.y, d.x)
		cam_a = car.a
	world.focus = car.pos
	return true


func _reset_to_road() -> void:
	if started and not busy and not _snap_to_road(400.0, false):
		hud.toast("مفيش شارع قريب")


func _next_color() -> void:
	color_i = (color_i + 1) % COLORS.size()
	car.model.set_color(Color.html(COLORS[color_i]))


# ------------------------------------------------------------------ map and travel
func open_map() -> void:
	if not started or busy:
		return
	running = false
	for n in game_nodes:
		n.set_process(false)
	world.visible = false
	car.visible = false
	traffic.visible = false
	nav.visible = false
	sun.visible = false
	hud.root.visible = false
	map_view.open(car.pos, nav.R if nav.active else {}, nav.dest_name)


func close_map() -> void:
	map_view.close()
	world.visible = true
	car.visible = true
	traffic.visible = true
	nav.visible = true
	sun.visible = true
	hud.root.visible = true
	for n in game_nodes:
		n.set_process(true)
	cam.make_current()
	running = started and not busy


## dest = {lat, lon, name}; mode = "here" (from where the car is) or "near" (start 3 km before the destination)
func _on_drive_requested(dest: Dictionary, mode: String) -> void:
	close_map()
	hud.toast("بحسب الطريق…")
	var from := Geo.unproj(car.pos)
	var R := await nav.fetch_route(from, Vector2(dest.lat, dest.lon))
	if R.is_empty():
		hud.toast(nav.err)
		return
	if mode == "here" or float(R.total) < 4200.0:
		nav.set_route(R, dest.name)
		_face_route()
		hud.toast("اتبع الخط الأزرق")
		return
	# jump to a point 3 km before the destination along the real route
	var target: float = float(R.total) - 3000.0
	var acc := 0.0
	var pi := 0
	var ll: PackedVector2Array = R.ll
	for i in range(1, ll.size()):
		acc += Geo.haversine(ll[i - 1].x, ll[i - 1].y, ll[i].x, ll[i].y)
		pi = i
		if acc >= target:
			break
	var fresh := await nav.fetch_route(ll[pi], Vector2(dest.lat, dest.lon))
	await _travel_to(ll[pi], fresh if not fresh.is_empty() else R, dest.name)


func _face_route() -> void:
	if not nav.active:
		return
	var pts: PackedVector2Array = nav.R.pts
	var i := mini(nav.idx, pts.size() - 2)
	var b := pts[mini(pts.size() - 1, i + 4)]
	var d := b - pts[i]
	if d.length() > 0.1:
		car.a = atan2(d.y, d.x)
		cam_a = car.a


func _set_fade(a: float, t: float = 0.4) -> void:
	var tw := create_tween()
	tw.tween_property(fade, "modulate:a", a, t)
	await tw.finished


## teleport to lat/lon (Vector2), load the real streets there and continue the given route
func _travel_to(ll: Vector2, route: Dictionary, dest_name: String, snap_idx_hint: int = 0) -> bool:
	if busy:
		return false
	busy = true
	running = false
	await _set_fade(1.0)
	nav.clear()
	world.new_trip(ll.x, ll.y)
	car.place(Vector2.ZERO, car.a)
	hud.toast("بحمّل الشوارع الحقيقية للمنطقة…")
	var t0 := Time.get_ticks_msec()
	var ok := false
	while Time.get_ticks_msec() - t0 < 40000:
		world.force_stream()
		if world.is_ready():
			ok = true
			break
		await get_tree().create_timer(0.16).timeout
	if ok:
		var snapped := _snap_to_road(450.0, false)
		traffic.reset(world)
		if not route.is_empty():
			nav.set_route(route, dest_name)
			_face_route()
		if not snapped:
			hud.toast("مفيش شارع قريب من النقطة دي، جرّب مكان تاني")
	else:
		hud.toast("تعذّر تحميل الشوارع هنا. تأكد من الاتصال بالإنترنت")
	_update_loc(true)
	await _set_fade(0.0)
	busy = false
	running = started
	return ok


func _jump_along(meters: float) -> void:
	if not nav.active or busy:
		return
	var R := nav.R
	var target := minf(R.len - 300.0, nav.s + meters)
	if target <= nav.s + 200.0:
		hud.toast("الوجهة قريبة، كمّل سواقة")
		return
	var cum: PackedFloat64Array = R.cum
	var idx := 0
	while idx < cum.size() - 1 and cum[idx] < target:
		idx += 1
	var ll: Vector2 = R.ll[idx]
	await _travel_to(ll, R, nav.dest_name)


func _jump_near() -> void:
	if not nav.active or busy:
		return
	if nav.R.len < 3200.0:
		hud.toast("أنت قريب من الوجهة أصلاً")
		return
	_jump_along(nav.R.len - 3000.0 - nav.s)


# ------------------------------------------------------------------ input
func _unhandled_key_input(e: InputEvent) -> void:
	var k := e as InputEventKey
	if k == null or not k.pressed or k.echo:
		return
	match k.physical_keycode:
		KEY_M:
			if map_view.visible:
				map_view.emit_signal("closed")
			else:
				open_map()
		KEY_R:
			if running:
				_reset_to_road()
		KEY_V:
			view_mode ^= 1
		KEY_C:
			if started:
				_next_color()
		KEY_J:
			_jump_along(5000.0)
		KEY_K:
			_jump_near()


func _inp() -> Dictionary:
	var t := hud.touch
	var l: bool = Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT) or t.left
	var r: bool = Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT) or t.right
	return {
		"throttle": 1.0 if (Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP) or t.gas) else 0.0,
		"brake": 1.0 if (Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN) or t.brake) else 0.0,
		"steer": (1.0 if r else 0.0) - (1.0 if l else 0.0),
		"hb": Input.is_physical_key_pressed(KEY_SPACE) or t.hb,
	}


# ------------------------------------------------------------------ loop
func _physics_process(dt: float) -> void:
	if not running or map_view.visible:
		return
	var inp := _inp()
	for _i in 2:
		car.step(dt / 2.0, inp, world, traffic.points())
	traffic.step(dt)
	nav.tick(dt, car.pos)
	world.rebase_if_needed()
	if absf(car.slide) > 3.5 and absf(car.spd) > 8.0:
		drift_pts += absf(car.slide) * dt * 6.0
	else:
		drift_pts = maxf(0.0, drift_pts - dt * 60.0)
	score += absf(car.spd) * dt * 0.02


func _process(dt: float) -> void:
	if map_view.visible:
		return
	car.sync_to(world)
	_update_camera(dt)
	_hud_t += dt
	if _hud_t > 0.1:
		_hud_t = 0.0
		_update_hud()
	if running:
		_loc_t += dt
		if _loc_t > 0.5:
			_loc_t = 0.0
			_update_loc(false)


func _update_camera(dt: float) -> void:
	var target_a := car.a
	if absf(car.spd) > 2.0 and car.spd < 0.0:
		target_a = car.a + PI
	cam_a = cam_a + Car.angle_diff(cam_a, car.a) * minf(1.0, dt * 4.5)
	var fwd := Vector3(cos(cam_a), 0, sin(cam_a))
	var cp := car.position
	if view_mode == 0:
		var back := 7.4 + clampf(absf(car.spd) * 0.05, 0.0, 3.0)
		var pos := cp - fwd * back + Vector3(0, 2.9 + clampf(absf(car.spd) * 0.012, 0.0, 0.8), 0)
		cam.position = cam.position.lerp(pos, minf(1.0, dt * 9.0)) if cam.position.distance_to(pos) < 40.0 else pos
		cam.look_at(cp + fwd * 5.0 + Vector3(0, 1.3, 0), Vector3.UP)
		cam.fov = 66.0 + clampf(absf(car.spd) * 0.15, 0.0, 12.0)
	else:
		var f2 := Vector3(cos(car.a), 0, sin(car.a))
		cam.position = cp + f2 * 0.3 + Vector3(0, 1.3, 0)
		cam.look_at(cam.position + f2 * 10.0 + Vector3(0, 0.0, 0), Vector3.UP)
		cam.fov = 75.0
	sun.position = cp + Vector3(0, 60, 0)


func _update_hud() -> void:
	hud.spd_lbl.text = str(int(round(absf(car.spd) * 3.6)))
	hud.score_lbl.text = "نقاط " + Geo.ar_num(str(int(score + drift_pts))) + "  ·  " + Geo.ar_num("%.1f" % (car.odo / 1000.0)) + " كم"
	hud.drift_lbl.text = ("انحراف +" + Geo.ar_num(str(int(drift_pts)))) if drift_pts > 25.0 else ""
	var net_busy := started and not busy and world.pending > 0
	hud.net_lbl.text = ("مش قادر أحمّل الشوارع الجديدة، بحاول تاني…" if (Net.last_err != "" and Time.get_ticks_msec() - Net.last_ok_ms > 8000) else "بحمّل شوارع جديدة…") if net_busy else ""
	nav.update_hud(hud)


func _update_loc(force: bool) -> void:
	var ll := Geo.unproj(car.pos)
	hud.xy_lbl.text = "%.4f%s %.4f%s" % [absf(ll.x), "N" if ll.x >= 0 else "S", absf(ll.y), "E" if ll.y >= 0 else "W"]
	hud.city_lbl.text = area_name
	hud.street_lbl.text = world.road_label(car.cur_road.f) if not car.cur_road.is_empty() and car.on_road else "خارج الطريق، العربية هتبطّأ"
	var now := Time.get_ticks_msec()
	if not _area_busy and (force or now - _area_t > 30000) and (force or car.pos.distance_to(_area_pos) > 700.0):
		_area_busy = true
		_area_t = now
		_area_pos = car.pos
		var r := await Net.reverse_name(ll.x, ll.y, 12)
		if r.has("area") and r.area != "":
			area_name = r.area
			hud.city_lbl.text = area_name
		_area_busy = false
