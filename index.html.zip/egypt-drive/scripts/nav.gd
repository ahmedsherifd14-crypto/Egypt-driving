class_name Nav
extends Node3D
## Turn-by-turn navigation on the real road network (OSRM), a blue guide line on the road and a beam at the destination.

signal arrived(dest_name: String)
signal rerouted

const DIR_AR := {
	"left": "لف شمال", "right": "لف يمين", "slight left": "انحرف شمال شوية", "slight right": "انحرف يمين شوية",
	"sharp left": "لف شمال بزاوية حادة", "sharp right": "لف يمين بزاوية حادة", "uturn": "اعمل دوران للخلف", "straight": "كمّل على استقامة",
}
const ARROW := {
	"left": "↰", "right": "↱", "slight left": "↖", "slight right": "↗", "sharp left": "↰", "sharp right": "↱", "uturn": "↶", "straight": "↑",
}

var world: World
var active: bool = false
var R: Dictionary = {}
var dest_name: String = ""
var dest_ll := Vector2.ZERO     # (lat, lon)
var idx: int = 0
var s: float = 0.0
var off_dist: float = 0.0
var voice: bool = false
var err: String = ""
var busy: bool = false

var _off_t: float = 0.0
var _cd: float = 0.0
var _scan_t: float = 0.0
var _said: Dictionary = {}
var _line: MeshInstance3D
var _beam: MeshInstance3D
var _line_origin := Vector2.ZERO
var _line_mat: ShaderMaterial


func _ready() -> void:
	add_to_group("origin_aware")
	_line_mat = ShaderMaterial.new()
	_line_mat.shader = load("res://shaders/route.gdshader")


func apply_origin() -> void:
	if _line != null:
		_line.position = world.to3(_line_origin)
	if _beam != null and not R.is_empty():
		_beam.position = world.to3(R.pts[R.pts.size() - 1], 80.0)


# ------------------------------------------------------------------ routing
## a, b = Vector2(lat, lon). Returns the parsed route or {} (reason in `err`).
func fetch_route(a: Vector2, b: Vector2) -> Dictionary:
	err = ""
	for base in Cfg.osrm:
		var url := "%s/route/v1/driving/%.6f,%.6f;%.6f,%.6f?overview=full&geometries=geojson&steps=true&alternatives=false" % [base, a.y, a.x, b.y, b.x]
		var j: Variant = await Net.get_json(url, 35.0)
		if j is Dictionary:
			if j.get("code", "") == "Ok" and (j.get("routes", []) as Array).size() > 0:
				return _parse(j["routes"][0])
			if j.get("code", "") == "NoRoute":
				err = "مفيش طريق للسيارات بين النقطتين دول"
				return {}
	err = "خدمة الطرق مردّتش. جرّب تاني بعد شوية"
	return {}


func _parse(rt: Dictionary) -> Dictionary:
	var ll := PackedVector2Array()
	for c in rt["geometry"]["coordinates"]:
		ll.append(Vector2(c[1], c[0]))
	var steps: Array = []
	for leg in rt["legs"]:
		for st in leg["steps"]:
			var m: Dictionary = st.get("maneuver", {})
			var loc: Array = m.get("location", [0, 0])
			steps.append({"type": str(m.get("type", "turn")), "mod": str(m.get("modifier", "")), "exit": int(m.get("exit", 1)),
				"name": str(st.get("name", "")), "ref": str(st.get("ref", "")), "dist": float(st.get("distance", 0)), "loc": Vector2(loc[1], loc[0]), "at": 0.0})
	return {"ll": ll, "steps": steps, "total": float(rt["distance"]), "dur": float(rt["duration"])}


func step_text(st: Dictionary) -> String:
	var nm: String = st.name if st.name != "" else st.ref
	var on := (" على " + nm) if nm != "" else ""
	var mod: String = st.mod
	var dir: String = DIR_AR.get(mod, "كمّل")
	match st.type:
		"depart":
			return "ابدأ السواقة" + on
		"arrive":
			return "وصلت وجهتك" + (" (على الشمال)" if mod == "left" else (" (على اليمين)" if mod == "right" else ""))
		"roundabout", "rotary":
			return "ادخل الدوّار وخُد المخرج رقم " + Geo.ar_num(str(st.exit))
		"roundabout turn":
			return "عند الدوّار " + dir
		"exit roundabout", "exit rotary":
			return "اخرج من الدوّار" + on
		"merge":
			return "ادخل في الطريق" + on
		"on ramp":
			return "اطلع على الطريق" + on
		"off ramp":
			return "انزل من الطريق" + on
		"fork":
			return ("خُد الشمال" if mod.contains("left") else ("خُد اليمين" if mod.contains("right") else "كمّل")) + " عند المفترق" + on
		"end of road":
			return "في نهاية الطريق " + dir + on
		"new name", "continue":
			return (dir if (mod != "" and mod != "straight") else "كمّل على استقامة") + on
	return dir + on


func step_arrow(st: Dictionary) -> String:
	if st.type == "arrive":
		return "⚑"
	if st.type in ["roundabout", "rotary", "roundabout turn"]:
		return "⟳"
	return ARROW.get(st.mod, "↑")


## project the route into the current trip frame and compute where each step happens along it
func project() -> void:
	var ll: PackedVector2Array = R.ll
	var pts := PackedVector2Array()
	var cum := PackedFloat64Array()
	for i in ll.size():
		pts.append(Geo.proj(ll[i].x, ll[i].y))
		cum.append(0.0 if i == 0 else cum[i - 1] + pts[i].distance_to(pts[i - 1]))
	R["pts"] = pts
	R["cum"] = cum
	R["len"] = maxf(cum[cum.size() - 1], 1.0)
	var expd := 0.0
	var from := 0
	for st in R.steps:
		var p := Geo.proj(st.loc.x, st.loc.y)
		var bi := from
		var bd := 1e18
		for i in range(from, pts.size()):
			if cum[i] > expd + 600.0 and bd < 1e17:
				break
			if cum[i] < expd - 600.0:
				continue
			var d := pts[i].distance_to(p)
			if d < bd:
				bd = d
				bi = i
		st["at"] = cum[bi]
		from = bi
		expd += st.dist
	if R.steps.size() > 0:
		R.steps[R.steps.size() - 1]["at"] = R.len


func set_route(route: Dictionary, nm: String, keep_progress: bool = false) -> void:
	R = route
	dest_name = nm
	dest_ll = R.ll[R.ll.size() - 1]
	project()
	if not keep_progress:
		idx = 0
		s = 0.0
		_said.clear()
	active = true
	_off_t = 0.0
	_cd = 6.0
	_build_visuals()


func clear() -> void:
	active = false
	R = {}
	if _line != null:
		_line.queue_free()
		_line = null
	if _beam != null:
		_beam.queue_free()
		_beam = null
	_said.clear()


func reproject_after_trip() -> void:
	## the trip frame changed (new origin): redo the projection but keep the road we were on
	if R.is_empty():
		return
	project()
	_build_visuals()


func _build_visuals() -> void:
	if _line != null:
		_line.queue_free()
	if _beam != null:
		_beam.queue_free()
	var pts: PackedVector2Array = R.pts
	_line_origin = pts[0]
	var mb := Osm.MB.new(_line_origin.x, _line_origin.y)
	Osm.ribbon(mb, pts, 3.6, 0.42, Color.WHITE, 0.0, 1.0)
	if not mb.is_empty():
		var m := ArrayMesh.new()
		m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, mb.arrays())
		_line = MeshInstance3D.new()
		_line.mesh = m
		_line.material_override = _line_mat
		_line.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		_line.extra_cull_margin = 16384.0
		add_child(_line)
		_line.position = world.to3(_line_origin)
	var cyl := CylinderMesh.new()
	cyl.top_radius = 3.0
	cyl.bottom_radius = 3.0
	cyl.height = 160.0
	var bm := StandardMaterial3D.new()
	bm.albedo_color = Color(0.2, 0.8, 1.0, 0.35)
	bm.emission_enabled = true
	bm.emission = Color(0.2, 0.8, 1.0)
	bm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	bm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_beam = MeshInstance3D.new()
	_beam.mesh = cyl
	_beam.material_override = bm
	_beam.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_beam)
	_beam.position = world.to3(pts[pts.size() - 1], 80.0)


# ------------------------------------------------------------------ per frame
func tick(dt: float, car_pos: Vector2) -> void:
	if not active or R.is_empty():
		return
	var pts: PackedVector2Array = R.pts
	var cum: PackedFloat64Array = R.cum
	var best := 1e18
	var bi := idx
	var bt := 0.0
	var lo := maxi(0, idx - 3)
	var hi := mini(pts.size() - 2, idx + 30)
	for i in range(lo, hi + 1):
		var q: Array = Geo.seg_dist(car_pos, pts[i], pts[i + 1])
		if q[0] < best:
			best = q[0]
			bi = i
			bt = q[1]
	_scan_t -= dt
	if best > 60.0 and _scan_t <= 0.0:
		_scan_t = 1.0
		for i in pts.size() - 1:
			var q2: Array = Geo.seg_dist(car_pos, pts[i], pts[i + 1])
			if q2[0] < best:
				best = q2[0]
				bi = i
				bt = q2[1]
	idx = bi
	s = cum[bi] + bt * (cum[bi + 1] - cum[bi])
	off_dist = best
	_cd -= dt
	if best > 55.0:
		_off_t += dt
		if _off_t > 3.0 and _cd <= 0.0 and not busy:
			_reroute(car_pos)
	else:
		_off_t = 0.0
	var remain: float = R.len - s
	if remain < 28.0:
		var nm := dest_name
		clear()
		arrived.emit(nm)
		return
	_announce(remain)


func _reroute(car_pos: Vector2) -> void:
	busy = true
	_cd = 8.0
	var nr := await fetch_route(Geo.unproj(car_pos), dest_ll)
	busy = false
	if active and not nr.is_empty():
		set_route(nr, dest_name)
		rerouted.emit()


func next_step() -> Dictionary:
	for st in R.steps:
		if st.at > s + 8.0 and st.type != "depart":
			return st
	return R.steps[R.steps.size() - 1] if R.steps.size() > 0 else {}


func _announce(_remain: float) -> void:
	if not voice:
		return
	var st := next_step()
	if st.is_empty():
		return
	var d: float = st.at - s
	var key := str(R.steps.find(st))
	for lim in [400.0, 150.0, 40.0]:
		var k: String = key + "_" + str(int(lim))
		if d < lim and not _said.has(k):
			_said[k] = true
			speak(("بعد " + Geo.fmt_dist(d) + " " + step_text(st)) if lim > 100.0 else step_text(st))
			break


func speak(text: String) -> void:
	var voices := DisplayServer.tts_get_voices_for_language("ar")
	if voices.size() > 0:
		DisplayServer.tts_speak(text, voices[0], 80)


func update_hud(h: Hud) -> void:
	h.nav_box.visible = active
	if not active:
		return
	var st := next_step()
	var d: float = maxf(0.0, st.at - s) if not st.is_empty() else 0.0
	h.nav_arrow.text = step_arrow(st) if not st.is_empty() else "↑"
	h.nav_dist.text = Geo.fmt_dist(d)
	h.nav_txt.text = step_text(st) if not st.is_empty() else ""
	var remain: float = R.len - s
	h.nav_bar.value = clampf(s / R.len, 0.0, 1.0) * 100.0
	var eta: float = R.dur * remain / R.len
	h.nav_sub.text = "الوجهة: %s  ·  باقي %s  ·  حوالي %s" % [dest_name, Geo.fmt_dist(remain), Geo.fmt_time(eta)] + ("  ·  برا المسار، بعيد الحساب…" if _off_t > 1.0 else "")
