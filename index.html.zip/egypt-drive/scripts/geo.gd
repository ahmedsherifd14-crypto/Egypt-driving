class_name Geo
extends RefCounted
## Projection between latitude/longitude and the local "trip frame" (metres, x = east, z = south,
## so north is -Z, the way Godot looks by default), plus small number/format helpers.

const KY := 111132.0
static var lat0: float = 31.43
static var lon0: float = 31.70
static var kx: float = 111320.0 * cos(deg_to_rad(31.43))


static func set_origin(la: float, lo: float) -> void:
	lat0 = la
	lon0 = lo
	kx = 111320.0 * cos(deg_to_rad(la))


static func proj(la: float, lo: float) -> Vector2:
	return Vector2((lo - lon0) * kx, -(la - lat0) * KY)


## returns Vector2(lat, lon)
static func unproj(p: Vector2) -> Vector2:
	return Vector2(lat0 - p.y / KY, lon0 + p.x / kx)


static func haversine(la1: float, lo1: float, la2: float, lo2: float) -> float:
	var d := PI / 180.0
	var a := pow(sin((la2 - la1) * d / 2.0), 2.0) + cos(la1 * d) * cos(la2 * d) * pow(sin((lo2 - lo1) * d / 2.0), 2.0)
	return 2.0 * 6371000.0 * asin(sqrt(a))


## cheap deterministic hash in [0,1) (same idea as the browser version)
static func hash3(a: int, b: int, s: int) -> float:
	var n: int = (((a & 0xFFFFFFFF) * 374761393) ^ ((b & 0xFFFFFFFF) * 668265263) ^ ((s & 0xFFFFFFFF) * 1442695041)) & 0xFFFFFFFF
	n = (((n ^ (n >> 13)) & 0xFFFFFFFF) * 1274126177) & 0xFFFFFFFF
	n = n ^ (n >> 16)
	return float(n & 0xFFFFFFFF) / 4294967296.0


static func ar_num(s: String) -> String:
	var out := ""
	for ch in s:
		var i := "0123456789".find(ch)
		out += "٠١٢٣٤٥٦٧٨٩"[i] if i >= 0 else ch
	return out


static func fmt_dist(m: float) -> String:
	if m < 950.0:
		return ar_num(str(maxi(10, int(round(m / 10.0)) * 10))) + " م"
	var km := m / 1000.0
	return ar_num(("%.1f" % km) if km < 10.0 else str(int(round(km)))) + " كم"


static func fmt_time(sec: float) -> String:
	var m := int(round(sec / 60.0))
	if m < 60:
		return ar_num(str(maxi(1, m))) + " د"
	return ar_num(str(m / 60)) + " س " + ar_num(str(m % 60)) + " د"


static func lin(hex: String) -> Color:
	var c := Color.html(hex)
	return Color(pow(c.r, 2.2), pow(c.g, 2.2), pow(c.b, 2.2), 1.0)


static func poly_area(p: PackedVector2Array) -> float:
	var a := 0.0
	var n := p.size()
	var j := n - 1
	for i in n:
		a += p[j].x * p[i].y - p[i].x * p[j].y
		j = i
	return a / 2.0


static func seg_dist(p: Vector2, a: Vector2, b: Vector2) -> Array:
	## [distance, t along segment, nearest point]
	var e := b - a
	var l2 := e.length_squared()
	var t := 0.0
	if l2 > 0.0:
		t = clampf((p - a).dot(e) / l2, 0.0, 1.0)
	var q := a + e * t
	return [p.distance_to(q), t, q]


## Douglas-Peucker
static func simplify(pts: PackedVector2Array, tol: float) -> PackedVector2Array:
	var n := pts.size()
	if n < 6:
		return pts
	var keep := PackedByteArray()
	keep.resize(n)
	keep[0] = 1
	keep[n - 1] = 1
	var stack: Array = [[0, n - 1]]
	while stack.size() > 0:
		var ab: Array = stack.pop_back()
		var a: int = ab[0]
		var b: int = ab[1]
		var md := 0.0
		var mi := -1
		for i in range(a + 1, b):
			var d: float = seg_dist(pts[i], pts[a], pts[b])[0]
			if d > md:
				md = d
				mi = i
		if md > tol and mi > 0:
			keep[mi] = 1
			stack.append([a, mi])
			stack.append([mi, b])
	var out := PackedVector2Array()
	for i in n:
		if keep[i] == 1:
			out.append(pts[i])
	return out
