extends Node
## Network layer (autoload "Net"): Overpass (OpenStreetMap data), OSRM (routing), Nominatim/Photon (search).
## Everything is a coroutine: `var r = await Net.overpass_text(query)`.

const UA := "EgyptDrive-Godot/1.0 (open-source driving game; contact via project page)"
var last_ok_ms: int = 0
var last_err: String = ""
var active: int = 0
var _mirror: int = 0
var _bad: Dictionary = {}       # url -> time (ms) until which this mirror is skipped


## request headers; a browser must not (and cannot) set its own User-Agent, and an extra header would force a CORS pre-flight
func _hd(list: Array) -> PackedStringArray:
	var out := PackedStringArray(list)
	if not OS.has_feature("web"):
		out.append("User-Agent: " + UA)
	return out


func _http(url: String, method: int, headers: PackedStringArray, body: String, timeout: float) -> Dictionary:
	var r := HTTPRequest.new()
	r.timeout = timeout
	r.accept_gzip = not OS.has_feature("web")       # browsers set their own Accept-Encoding
	add_child(r)
	var e := r.request(url, headers, method, body)
	if e != OK:
		r.queue_free()
		return {"ok": false, "code": 0, "err": "request error %d" % e, "body": PackedByteArray()}
	var res: Array = await r.request_completed
	r.queue_free()
	if int(res[0]) != HTTPRequest.RESULT_SUCCESS:
		return {"ok": false, "code": 0, "err": "network error %d" % int(res[0]), "body": PackedByteArray()}
	var code: int = res[1]
	return {"ok": code >= 200 and code < 300, "code": code, "err": "HTTP %d" % code, "body": res[3]}


## GET a URL and parse JSON. Returns null on any failure (the reason is in last_err).
func get_json(url: String, timeout: float = 15.0) -> Variant:
	active += 1
	var r := await _http(url, HTTPClient.METHOD_GET, _hd(["Accept: application/json"]), "", timeout)
	active -= 1
	if not r.ok:
		last_err = r.err
		return null
	var v: Variant = JSON.parse_string((r.body as PackedByteArray).get_string_from_utf8())
	if v == null:
		last_err = "bad JSON"
		return null
	last_ok_ms = Time.get_ticks_msec()
	last_err = ""
	return v


## POST an Overpass query, rotating through the mirrors. Returns the raw JSON text, or "" if every mirror failed.
func overpass_text(query: String) -> String:
	var list: Array = Cfg.overpass
	active += 1
	var out := ""
	for round_i in 2:
		for n in list.size():
			var i := (_mirror + n) % list.size()
			var url: String = list[i]
			if _bad.has(url) and Time.get_ticks_msec() < int(_bad[url]):
				continue
			var hd := _hd(["Content-Type: application/x-www-form-urlencoded"])
			var r := await _http(url, HTTPClient.METHOD_POST, hd, "data=" + query.uri_encode(), 45.0)
			if not r.ok:
				_bad[url] = Time.get_ticks_msec() + (25000 if int(r.code) == 429 else 9000)
				last_err = r.err
				continue
			var txt: String = (r.body as PackedByteArray).get_string_from_utf8()
			if not txt.begins_with("{"):
				_bad[url] = Time.get_ticks_msec() + 9000
				last_err = "bad reply"
				continue
			_mirror = i
			last_ok_ms = Time.get_ticks_msec()
			last_err = ""
			out = txt
			break
		if out != "":
			break
		await get_tree().create_timer(1.5).timeout
	active -= 1
	return out


## Nominatim search restricted to Egypt, with Photon as the fallback. Returns [{name, short, lat, lon}]
func geocode(q: String, limit: int = 6) -> Array:
	var out: Array = []
	var j: Variant = await get_json("%s/search?format=jsonv2&limit=%d&countrycodes=eg&accept-language=ar&q=%s" % [Cfg.nominatim, limit, q.uri_encode()], 10.0)
	if j is Array:
		for r in j:
			out.append({"name": str(r.get("display_name", "")), "short": str(r.get("name", "")), "lat": float(r.get("lat", 0)), "lon": float(r.get("lon", 0))})
	if out.size() > 0:
		return out
	j = await get_json("%s/api/?limit=%d&lat=27&lon=30.8&q=%s" % [Cfg.photon, limit, q.uri_encode()], 10.0)
	if j is Dictionary:
		for f in j.get("features", []):
			var p: Dictionary = f.get("properties", {})
			if p.has("countrycode") and p["countrycode"] != "EG":
				continue
			var parts: Array = []
			for k in ["name", "street", "city", "state"]:
				if p.has(k) and str(p[k]) != "":
					parts.append(str(p[k]))
			var co: Array = f["geometry"]["coordinates"]
			out.append({"name": "، ".join(parts), "short": str(p.get("name", "")), "lat": float(co[1]), "lon": float(co[0])})
	return out


## Short place name for a position: {area, full}. Empty dictionary if the lookup fails.
func reverse_name(lat: float, lon: float, zoom: int = 14) -> Dictionary:
	var j: Variant = await get_json("%s/reverse?format=jsonv2&zoom=%d&accept-language=ar&lat=%f&lon=%f" % [Cfg.nominatim, zoom, lat, lon], 8.0)
	if j is Dictionary:
		var a: Dictionary = j.get("address", {})
		var area := ""
		for k in ["city", "town", "village", "suburb", "county", "state"]:
			if a.has(k):
				area = str(a[k])
				break
		return {"area": area, "full": str(j.get("display_name", ""))}
	return {}
