class_name Car
extends Node3D
## The player's car: arcade physics in the trip frame (doubles), drawn relative to the render origin.

const WHEELBASE := 2.65
const VMAX := 62.0

var pos := Vector2.ZERO
var vel := Vector2.ZERO
var a: float = -PI / 2.0        # heading: forward = (cos a, sin a) in (x, z); a = -PI/2 faces north
var steer: float = 0.0
var spd: float = 0.0            # signed forward speed (m/s)
var slide: float = 0.0          # lateral speed (m/s), for drift scoring
var cur_road: Dictionary = {}
var on_road: bool = true
var odo: float = 0.0
var model: CarModel
var _roll: float = 0.0
var _pitch: float = 0.0
var _last_vf: float = 0.0


static func angle_diff(a0: float, b0: float) -> float:
	var d := fmod(b0 - a0 + PI, TAU)
	if d < 0.0:
		d += TAU
	return d - PI


func _ready() -> void:
	add_to_group("origin_aware")
	model = CarModel.new()
	add_child(model)


func apply_origin() -> void:
	pass   # main.gd places the car every frame


func forward() -> Vector2:
	return Vector2(cos(a), sin(a))


func place(p: Vector2, heading: float) -> void:
	pos = p
	a = heading
	vel = Vector2.ZERO
	steer = 0.0
	spd = 0.0


## input: {throttle 0..1, brake 0..1, steer -1..1 (right positive), hb bool}
func step(dt: float, inp: Dictionary, world: World, traffic_pts: Array) -> void:
	var fwd := forward()
	var right := Vector2(-fwd.y, fwd.x)
	var vf := vel.dot(fwd)
	var vl := vel.dot(right)
	var thr: float = inp.throttle
	var brk: float = inp.brake
	var hb: bool = inp.hb
	var target: float = float(inp.steer) * lerpf(0.55, 0.085, clampf(absf(vf) / 42.0, 0.0, 1.0))
	steer = move_toward(steer, target, dt * (3.2 if absf(target) > absf(steer) else 5.0))
	var acc := 0.0
	if thr > 0.0:
		acc += thr * (11.0 * (1.0 - clampf(vf / VMAX, 0.0, 1.0)) + (3.0 if vf < 12.0 else 0.0))
	if brk > 0.0:
		if vf > 0.6:
			acc -= 30.0 * brk
		else:
			acc -= 7.0 * brk * (1.0 if vf > -9.0 else 0.0)
	if hb:
		acc -= 14.0 * signf(vf)
	vf += acc * dt
	vf -= vf * absf(vf) * 0.0017 * dt
	if thr == 0.0 and brk == 0.0 and not hb:
		vf = move_toward(vf, 0.0, 1.6 * dt)
	var grip := 1.4 if hb and absf(vf) > 6.0 else 9.0
	vl *= exp(-grip * dt)
	if not on_road:
		vf *= exp(-0.55 * dt)
		vl *= exp(-1.0 * dt)
	if absf(vf) > 0.05:
		a += (vf / WHEELBASE) * tan(steer) * dt * (1.0 + (0.6 if hb else 0.0))
	var f2 := forward()
	var r2 := Vector2(-f2.y, f2.x)
	vel = f2 * vf + r2 * vl
	pos += vel * dt
	spd = vf
	slide = vl
	odo += absf(vf) * dt
	# buildings and water edges: two circles along the body
	for _it in 2:
		var f3 := forward()
		for off in [1.25, -1.25]:
			var c: Vector2 = pos + f3 * off
			var push := world.collide_circle(c, 1.0)
			if push.length() > 0.0:
				pos += push
				var nrm := push.normalized()
				var vn := vel.dot(nrm)
				if vn < 0.0:
					vel -= nrm * vn * 1.25
					vel *= 0.985
	# other cars
	for tp in traffic_pts:
		var d: Vector2 = pos - tp
		var l := d.length()
		if l < 2.4 and l > 0.001:
			pos += d / l * (2.4 - l) * 0.6
			vel *= 0.97
	world.focus = pos
	world.focus_vel = vel
	var q := world.road_at(pos, 28.0)
	cur_road = q
	on_road = not q.is_empty() and float(q.d) < float(q.f.w) / 2.0 + 1.6
	# body motion
	var lat_acc := vl * 0.012
	_roll = lerpf(_roll, clampf(-lat_acc - steer * vf * 0.004, -0.09, 0.09), minf(1.0, dt * 6.0))
	_pitch = lerpf(_pitch, clampf(-(vf - _last_vf) / maxf(dt, 0.001) * 0.0035, -0.06, 0.06), minf(1.0, dt * 6.0))
	_last_vf = vf
	model.animate(vf * dt, steer)


func sync_to(world: World) -> void:
	position = world.to3(pos, 0.2)
	rotation = Vector3(0, -a, 0)
	model.rotation = Vector3(_roll, 0, _pitch)
