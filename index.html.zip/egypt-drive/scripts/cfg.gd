extends Node
## Global settings (autoload "Cfg"): map servers, start point, the city list.
## Servers can be overridden from the command line (used by the tests):
##   godot --path . -- --overpass=URL --osrm=URL --nominatim=URL --photon=URL

var overpass: Array = [
	"https://overpass-api.de/api/interpreter",
	"https://overpass.kumi.systems/api/interpreter",
	"https://overpass.private.coffee/api/interpreter",
	"https://maps.mail.ru/osm/tools/overpass/api/interpreter",
]
var osrm: Array = ["https://router.project-osrm.org", "https://routing.openstreetmap.de/routed-car"]
var nominatim: String = "https://nominatim.openstreetmap.org"
var photon: String = "https://photon.komoot.io"
var custom: bool = false        # test servers: never cache their answers
var autotest: String = ""

const CELL := 0.015             # streaming grid in degrees (about 1.6 km)

# New Damietta (approximate). The real position of Capital Care Hospital is looked up by name at start.
var start: Dictionary = {"lat": 31.43, "lon": 31.70, "found": false}

const CITIES := [
	["القاهرة", 30.0444, 31.2357], ["الجيزة", 30.0131, 31.2089], ["القاهرة الجديدة", 30.0074, 31.4913],
	["6 أكتوبر", 29.9285, 30.9188], ["الإسكندرية", 31.2001, 29.9187], ["دمياط", 31.4165, 31.8133],
	["رأس البر", 31.5167, 31.8333], ["بورسعيد", 31.2653, 32.3019], ["المنصورة", 31.0409, 31.3785],
	["طنطا", 30.7865, 31.0004], ["الزقازيق", 30.5877, 31.5020], ["الإسماعيلية", 30.5965, 32.2715],
	["السويس", 29.9668, 32.5498], ["العين السخنة", 29.5928, 32.3412], ["الفيوم", 29.3084, 30.8428],
	["بني سويف", 29.0661, 31.0994], ["المنيا", 28.1099, 30.7503], ["أسيوط", 27.1809, 31.1837],
	["سوهاج", 26.5569, 31.6948], ["الأقصر", 25.6872, 32.6396], ["أسوان", 24.0889, 32.8998],
	["الغردقة", 27.2579, 33.8116], ["شرم الشيخ", 27.9158, 34.3300], ["مرسى مطروح", 31.3543, 27.2373],
	["كفر الشيخ", 31.1107, 30.9388], ["دمنهور", 31.0341, 30.4682], ["بنها", 30.4660, 31.1848],
	["العلمين", 30.8300, 28.9540],
]


func _ready() -> void:
	if OS.has_feature("web"):
		# a web page can point the game at other servers: index.html?overpass=URL&osrm=URL&nominatim=URL&photon=URL
		var qs := str(JavaScriptBridge.eval("window.location.search", true)).trim_prefix("?")
		for kv in qs.split("&"):
			var p := kv.split("=", true, 1)
			if p.size() == 2:
				var val := p[1].uri_decode()
				match p[0]:
					"overpass":
						overpass = [val]
						custom = true
					"osrm":
						osrm = [val]
						custom = true
					"nominatim":
						nominatim = val
					"photon":
						photon = val
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--overpass="):
			overpass = [a.substr(11)]
			custom = true
		elif a.begins_with("--osrm="):
			osrm = [a.substr(7)]
			custom = true
		elif a.begins_with("--nominatim="):
			nominatim = a.substr(12)
		elif a.begins_with("--photon="):
			photon = a.substr(9)
		elif a.begins_with("--autotest="):
			autotest = a.substr(11)
