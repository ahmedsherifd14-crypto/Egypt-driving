class_name World
extends Node3D
## The real world around the car: streams OpenStreetMap cells, builds their meshes, and answers questions
## ("which road is this", "did the car hit a building"). Data lives in the trip frame (metres, doubles);
## nodes are placed relative to `origin` so single-precision floats never lose accuracy on long drives.

const BK := 48.0                # road segment buckets (m)
const BS := 64.0                # obstacle buckets (m)
const LOAD_R := 900.0           # cells within this distance of the car are loaded
const KEEP_R := 2600.0          # meshes further than this are freed
const MAX_CELLS := 36
const MAX_LOADS := 2

var gen: int = 0
var cells: Dictionary = {}      # Vector2i(ci,cj) -> cell dictionary
var seg_grid: Dictionary = {}   # Vector2i -> Array of [frag, i]
var sol_grid: Dictionary = {}   # Vector2i -> Array of solid dictionaries
var nodes: Dictionary = {}      # Vector2i(round(x*10), round(z*10)) -> Array of [frag, i]
var big: Dictionary = {}        # key -> {node, refs, solids, ax, az}
var origin := Vector2.ZERO      # render origin, trip frame
var focus := Vector2.ZERO       # the car, trip frame
var focus_vel := Vector2.ZERO
var pending: int = 0
var total: int = 0
var loads: int = 0
var last_need: Array = []

var _mutex := Mutex.new()
var _done: Array = []
var _uid: int = 0
var _timer: float = 0.0
var _mat_flat: StandardMaterial3D
var _mat_road: ShaderMaterial
var _mat_bld: ShaderMaterial
var ground: MeshInstance3D


func _ready() -> void:
	add_to_group("origin_aware")
	_mat_flat = StandardMaterial3D.new()
	_mat_flat.vertex_color_use_as_albedo = true
	_mat_flat.roughness = 0.95
	_mat_flat.cull_mode = BaseMaterial3D.CULL_DISABLED
	_mat_road = ShaderMaterial.new()
	_mat_road.shader = load("res://shaders/road.gdshader")
	_mat_bld = ShaderMaterial.new()
	_mat_bld.shader = load("res://shaders/facade.gdshader")
	ground = MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(9000, 9000)
	ground.mesh = pm
	var gm := StandardMaterial3D.new()
	gm.albedo_color = Geo.lin("#b4a98a")
	gm.roughness = 1.0
	gm.cull_mode = BaseMaterial3D.CULL_DISABLED
	ground.material_override = gm
	ground.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(ground)


func to3(p: Vector2, y: float = 0.0) -> Vector3:
	return Vector3(p.x - origin.x, y, p.y - origin.y)


func apply_origin() -> void:
	for c in cells.values():
		if c.node != null:
			c.node.position = Vector3(c.ax - origin.x, 0, c.az - origin.y)
	for b in big.values():
		b.node.position = Vector3(b.ax - origin.x, 0, b.az - origin.y)
	_move_ground()


func _move_ground() -> void:
	var s := 200.0
	ground.position = Vector3(roundf((focus.x) / s) * s - origin.x, 0.0, roundf((focus.y) / s) * s - origin.y)


## Move the render origin to the car whenever it has wandered 1.5 km away.
func rebase_if_needed() -> void:
	if focus.distance_to(origin) > 1500.0:
		origin = focus.round()
		get_tree().call_group("origin_aware", "apply_origin")


func new_trip(lat: float, lon: float) -> void:
	_clear_all()
	gen += 1
	Geo.set_origin(lat, lon)
	origin = Vector2.ZERO
	focus = Vector2.ZERO
	last_need = []
	_move_ground()


func _clear_all() -> void:
	for c in cells.values():
		if c.node != null:
			c.node.queue_free()
	for b in big.values():
		b.node.queue_free()
	cells.clear()
	seg_grid.clear()
	sol_grid.clear()
	nodes.clear()
	big.clear()
	_mutex.lock()
	_done.clear()
	_mutex.unlock()
	loads = 0


# ------------------------------------------------------------------ streaming
func _cell(ci: int, cj: int) -> Dictionary:
	var k := Vector2i(ci, cj)
	if cells.has(k):
		return cells[k]
	var cen := Geo.proj((cj + 0.5) * Osm.CELL, (ci + 0.5) * Osm.CELL)
	var c := {"k": k, "ci": ci, "cj": cj, "ax": cen.x, "az": cen.y, "state": 0, "node": null, "roads": [], "solids": [], "bigs": [], "retry": 0}
	cells[k] = c
	return c


func _need_cells() -> Array:
	var pts: Array = [focus]
	if focus_vel.length() > 6.0:
		pts.append(focus + focus_vel * 7.0)
	var need := {}
	for p in pts:
		var ll := Geo.unproj(p)
		var dla := LOAD_R / Geo.KY
		var dlo := LOAD_R / Geo.kx
		for ci in range(floori((ll.y - dlo) / Osm.CELL), floori((ll.y + dlo) / Osm.CELL) + 1):
			for cj in range(floori((ll.x - dla) / Osm.CELL), floori((ll.x + dla) / Osm.CELL) + 1):
				var c := _cell(ci, cj)
				need[c.k] = c
	var out: Array = need.values()
	out.sort_custom(func(a, b): return Vector2(a.ax, a.az).distance_to(focus) < Vector2(b.ax, b.az).distance_to(focus))
	return out


func _process(delta: float) -> void:
	_timer += delta
	if _timer >= 0.16:
		_timer = 0.0
		_stream()
	_finalize_ready(2)
	_move_ground()


func _stream() -> void:
	var now := Time.get_ticks_msec()
	var need := _need_cells()
	last_need = need
	for c in need:
		if loads >= MAX_LOADS:
			break
		if c.state == 0 or (c.state == 3 and now > int(c.retry)):
			_load_cell(c)
	for c in cells.values():
		if c.node != null and Vector2(c.ax, c.az).distance_to(focus) > KEEP_R:
			_drop_mesh(c)
	if cells.size() > MAX_CELLS:
		var need_keys := {}
		for c in need:
			need_keys[c.k] = true
		var far: Array = []
		for c in cells.values():
			if c.state != 1 and not need_keys.has(c.k):
				far.append(c)
		far.sort_custom(func(a, b): return Vector2(a.ax, a.az).distance_to(focus) > Vector2(b.ax, b.az).distance_to(focus))
		for i in mini(far.size(), cells.size() - MAX_CELLS):
			_drop_cell(far[i])
	pending = 0
	for c in need:
		if c.state != 2:
			pending += 1
	total = need.size()


func is_ready() -> bool:
	if last_need.is_empty():
		return false
	for i in mini(4, last_need.size()):
		if last_need[i].state != 2:
			return false
	return true


func force_stream() -> void:
	_stream()
	_finalize_ready(9)


func _cache_path(c: Dictionary) -> String:
	return "user://cache/c_%d_%d.gz" % [c.ci, c.cj]


func _cache_read(c: Dictionary) -> String:
	var p := _cache_path(c)
	if not FileAccess.file_exists(p):
		return ""
	if Time.get_unix_time_from_system() - FileAccess.get_modified_time(p) > 30.0 * 86400.0:
		return ""
	var f := FileAccess.open_compressed(p, FileAccess.READ, FileAccess.COMPRESSION_GZIP)
	if f == null:
		return ""
	var t := f.get_as_text()
	return t if t.begins_with("{") else ""


func _cache_write(c: Dictionary, text: String) -> void:
	DirAccess.make_dir_recursive_absolute("user://cache")
	var f := FileAccess.open_compressed(_cache_path(c), FileAccess.WRITE, FileAccess.COMPRESSION_GZIP)
	if f != null:
		f.store_string(text)


func _load_cell(c: Dictionary) -> void:
	c.state = 1
	loads += 1
	var g := gen
	var text := ""
	if not Cfg.custom:
		text = _cache_read(c)
	if text == "":
		text = await Net.overpass_text(Osm.query_for(c.ci, c.cj))
		if text != "" and not Cfg.custom and g == gen:
			_cache_write(c, text)
	if g != gen:
		return
	loads -= 1
	if text == "":
		c.state = 3
		c.retry = Time.get_ticks_msec() + 7000
		return
	var tid := WorkerThreadPool.add_task(_work.bind(c, text, g))
	c["tid"] = tid


func _work(c: Dictionary, text: String, g: int) -> void:
	var r := Osm.process(c.ci, c.cj, text)
	_mutex.lock()
	_done.append([c, g, r])
	_mutex.unlock()


func _finalize_ready(budget: int) -> void:
	while budget > 0:
		_mutex.lock()
		var item: Array = [] if _done.is_empty() else _done.pop_front()
		_mutex.unlock()
		if item.is_empty():
			return
		var c: Dictionary = item[0]
		if c.has("tid"):
			WorkerThreadPool.wait_for_task_completion(int(c["tid"]))
			c.erase("tid")
		if int(item[1]) != gen or not cells.has(c.k) or cells[c.k] != c:
			continue
		budget -= 1
		_ingest(c, item[2])


func _mesh_of(arrays: Array, mat: Material, shadow: bool) -> MeshInstance3D:
	var m := ArrayMesh.new()
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	var mi := MeshInstance3D.new()
	mi.mesh = m
	mi.material_override = mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if shadow else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return mi


func _ingest(c: Dictionary, r: Dictionary) -> void:
	if not r.get("ok", false):
		c.state = 3
		c.retry = Time.get_ticks_msec() + 7000
		return
	c.state = 2
	c.ax = r.ax
	c.az = r.az
	var holder := Node3D.new()
	holder.position = Vector3(c.ax - origin.x, 0, c.az - origin.y)
	if not (r.flat as Array).is_empty():
		holder.add_child(_mesh_of(r.flat, _mat_flat, false))
	if not (r.rd as Array).is_empty():
		holder.add_child(_mesh_of(r.rd, _mat_road, false))
	if not (r.bw as Array).is_empty():
		holder.add_child(_mesh_of(r.bw, _mat_bld, true))
	add_child(holder)
	c.node = holder
	c.roads = r.roads
	for f in c.roads:
		f["cell"] = c.k
		_index_road(f)
	for s in r.solids:
		s["cell"] = c.k
		_add_solid(s)
		c.solids.append(s)
	for b in r.bigs:
		var key: String = b.key
		c.bigs.append(key)
		if big.has(key):
			big[key].refs[c.k] = true
			continue
		if (b.arrays as Array).is_empty():
			continue
		var bn := Node3D.new()
		bn.position = Vector3(b.ax - origin.x, 0, b.az - origin.y)
		bn.add_child(_mesh_of(b.arrays, _mat_flat, false))
		add_child(bn)
		var entry := {"node": bn, "refs": {c.k: true}, "solids": [], "ax": b.ax, "az": b.az}
		for w in b.walls:
			var wall := {"pts": w, "closed": false, "kind": "water", "cell": key}
			_add_solid(wall)
			entry.solids.append(wall)
		big[key] = entry


func _drop_mesh(c: Dictionary) -> void:
	if c.node != null:
		c.node.queue_free()
		c.node = null


func _drop_cell(c: Dictionary) -> void:
	_drop_mesh(c)
	var touched := {}
	var node_keys := {}
	for f in c.roads:
		var P: PackedVector2Array = f.pts
		for i in P.size() - 1:
			for k in _seg_keys(P[i], P[i + 1]):
				touched[k] = true
		for p in P:
			node_keys[_nkey(p)] = true
	for k in touched:
		if seg_grid.has(k):
			var keep: Array = seg_grid[k].filter(func(e): return e[0]["cell"] != c.k)
			if keep.is_empty():
				seg_grid.erase(k)
			else:
				seg_grid[k] = keep
	for k in node_keys:
		if nodes.has(k):
			var keep2: Array = nodes[k].filter(func(e): return e[0]["cell"] != c.k)
			if keep2.is_empty():
				nodes.erase(k)
			else:
				nodes[k] = keep2
	for s in c.solids:
		_del_solid(s)
	for key in c.bigs:
		if big.has(key):
			big[key].refs.erase(c.k)
			if big[key].refs.is_empty():
				for s in big[key].solids:
					_del_solid(s)
				big[key].node.queue_free()
				big.erase(key)
	cells.erase(c.k)


# ------------------------------------------------------------------ spatial indexes
func _nkey(p: Vector2) -> Vector2i:
	return Vector2i(roundi(p.x * 10.0), roundi(p.y * 10.0))


func _seg_keys(a: Vector2, b: Vector2) -> Array:
	var n := maxi(1, ceili(a.distance_to(b) / (BK / 2.0)))
	var seen := {}
	var out: Array = []
	for q in n + 1:
		var p := a.lerp(b, float(q) / n)
		var k := Vector2i(floori(p.x / BK), floori(p.y / BK))
		if not seen.has(k):
			seen[k] = true
			out.append(k)
	return out


func _index_road(f: Dictionary) -> void:
	var P: PackedVector2Array = f.pts
	for i in P.size() - 1:
		for k in _seg_keys(P[i], P[i + 1]):
			if not seg_grid.has(k):
				seg_grid[k] = []
			seg_grid[k].append([f, i])
	for i in P.size():
		var nk := _nkey(P[i])
		if not nodes.has(nk):
			nodes[nk] = []
		nodes[nk].append([f, i])


func _add_solid(s: Dictionary) -> void:
	var P: PackedVector2Array = s.pts
	var mn := Vector2(1e18, 1e18)
	var mx := Vector2(-1e18, -1e18)
	for q in P:
		mn = Vector2(minf(mn.x, q.x), minf(mn.y, q.y))
		mx = Vector2(maxf(mx.x, q.x), maxf(mx.y, q.y))
	s["mn"] = mn
	s["mx"] = mx
	_uid += 1
	s["uid"] = _uid
	for i in range(floori(mn.x / BS), floori(mx.x / BS) + 1):
		for j in range(floori(mn.y / BS), floori(mx.y / BS) + 1):
			var k := Vector2i(i, j)
			if not sol_grid.has(k):
				sol_grid[k] = []
			sol_grid[k].append(s)


func _del_solid(s: Dictionary) -> void:
	for i in range(floori(s.mn.x / BS), floori(s.mx.x / BS) + 1):
		for j in range(floori(s.mn.y / BS), floori(s.mx.y / BS) + 1):
			var k := Vector2i(i, j)
			if sol_grid.has(k):
				var keep: Array = sol_grid[k].filter(func(o): return o["uid"] != s["uid"])
				if keep.is_empty():
					sol_grid.erase(k)
				else:
					sol_grid[k] = keep


# ------------------------------------------------------------------ queries (trip frame)
## nearest road within maxd: {d, f, i, t, p} or {}
func road_at(p: Vector2, maxd: float) -> Dictionary:
	var bx := floori(p.x / BK)
	var bz := floori(p.y / BK)
	var rr := maxi(1, ceili(maxd / BK))
	var best := {}
	var bd := maxd
	for i in range(bx - rr, bx + rr + 1):
		for j in range(bz - rr, bz + rr + 1):
			var arr: Array = seg_grid.get(Vector2i(i, j), [])
			for e in arr:
				var f: Dictionary = e[0]
				var P: PackedVector2Array = f.pts
				var q: Array = Geo.seg_dist(p, P[e[1]], P[e[1] + 1])
				if q[0] < bd:
					bd = q[0]
					best = {"d": q[0], "f": f, "i": e[1], "t": q[1], "p": q[2]}
	return best


func road_label(f: Dictionary) -> String:
	if str(f.name) != "":
		return f.name
	if str(f.ref) != "":
		return f.ref
	return Osm.HWNAME.get(f.cls, "طريق")


## circle against buildings and water edges. Returns the push-out vector (zero if free).
func collide_circle(p: Vector2, r: float) -> Vector2:
	var push := Vector2.ZERO
	var seen := {}
	for i in range(floori((p.x - r) / BS), floori((p.x + r) / BS) + 1):
		for j in range(floori((p.y - r) / BS), floori((p.y + r) / BS) + 1):
			var arr: Array = sol_grid.get(Vector2i(i, j), [])
			for s in arr:
				if seen.has(s.uid):
					continue
				seen[s.uid] = true
				if p.x + r < s.mn.x or p.x - r > s.mx.x or p.y + r < s.mn.y or p.y - r > s.mx.y:
					continue
				var P: PackedVector2Array = s.pts
				var inside: bool = s.closed and Geometry2D.is_point_in_polygon(p, P)
				var bd := 1e18
				var bq := p
				var n := P.size()
				var last := n if s.closed else n - 1
				for k in last:
					var q: Array = Geo.seg_dist(p, P[k], P[(k + 1) % n])
					if q[0] < bd:
						bd = q[0]
						bq = q[2]
				if inside:
					var dir := bq - p
					if dir.length() > 0.001:
						push += dir.normalized() * (bd + r)
				elif bd < r and bd > 0.0001:
					push += (p - bq).normalized() * (r - bd)
	return push
