class_name Hud
extends CanvasLayer
## All on-screen UI for driving: speedometer, street sign, navigation panel, buttons, start sheet, touch pad.

signal start_pressed
signal retry_pressed
signal map_pressed
signal reset_pressed
signal view_pressed
signal color_pressed
signal nav_cancel_pressed
signal jump_pressed
signal jump_near_pressed
signal voice_toggled(on: bool)

const GREEN := Color("0e7c4a")
const PANEL := Color(0.055, 0.07, 0.085, 0.82)

var root: Control
var theme_: Theme
var touch := {"left": false, "right": false, "gas": false, "brake": false, "hb": false}

var spd_lbl: Label
var unit_lbl: Label
var city_lbl: Label
var street_lbl: Label
var xy_lbl: Label
var toast_lbl: Label
var net_lbl: Label
var drift_lbl: Label
var score_lbl: Label
var nav_box: PanelContainer
var nav_arrow: Label
var nav_dist: Label
var nav_txt: Label
var nav_sub: Label
var nav_bar: ProgressBar
var nav_voice: Button
var start_box: PanelContainer
var start_msg: Label
var start_btn: Button
var retry_btn: Button
var arrive_box: PanelContainer
var arrive_lbl: Label
var _toast_t: float = 0.0


func _ready() -> void:
	layer = 5
	theme_ = Theme.new()
	var f: Font = load("res://fonts/DejaVuSans.ttf")
	theme_.default_font = f
	theme_.default_font_size = 18
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.theme = theme_
	add_child(root)
	_build_hud()
	_build_nav()
	_build_start()
	_build_arrive()
	if DisplayServer.is_touchscreen_available():
		_build_touch()


func _sb(color: Color, radius: int = 8, pad: int = 10) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = color
	s.set_corner_radius_all(radius)
	s.content_margin_left = pad
	s.content_margin_right = pad
	s.content_margin_top = pad * 0.6
	s.content_margin_bottom = pad * 0.6
	return s


func _label(text: String, size: int = 18, color: Color = Color.WHITE, align: int = HORIZONTAL_ALIGNMENT_CENTER) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = align
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.6))
	l.add_theme_constant_override("outline_size", 3)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func _button(text: String, on_press: Callable, big: bool = false) -> Button:
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", 22 if big else 16)
	b.custom_minimum_size = Vector2(190 if big else 0, 0)
	b.add_theme_stylebox_override("normal", _sb(Color(0.12, 0.14, 0.17, 0.88), 8, 12))
	b.add_theme_stylebox_override("hover", _sb(Color(0.2, 0.24, 0.28, 0.95), 8, 12))
	b.add_theme_stylebox_override("pressed", _sb(GREEN, 8, 12))
	b.pressed.connect(on_press)
	return b


func _build_hud() -> void:
	# street sign, top right
	var sign_box := PanelContainer.new()
	sign_box.add_theme_stylebox_override("panel", _sb(GREEN, 6, 14))
	sign_box.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	sign_box.position = Vector2(-16, 12)
	sign_box.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	sign_box.custom_minimum_size = Vector2(260, 0)
	sign_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var v := VBoxContainer.new()
	sign_box.add_child(v)
	city_lbl = _label("", 20, Color.WHITE, HORIZONTAL_ALIGNMENT_RIGHT)
	street_lbl = _label("", 16, Color(1, 1, 1, 0.92), HORIZONTAL_ALIGNMENT_RIGHT)
	xy_lbl = _label("", 13, Color(1, 1, 1, 0.75), HORIZONTAL_ALIGNMENT_RIGHT)
	v.add_child(city_lbl)
	v.add_child(street_lbl)
	v.add_child(xy_lbl)
	root.add_child(sign_box)
	# speedometer, bottom left
	var sp := PanelContainer.new()
	sp.add_theme_stylebox_override("panel", _sb(PANEL, 8, 14))
	sp.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	sp.position = Vector2(16, -16)
	sp.grow_vertical = Control.GROW_DIRECTION_BEGIN
	sp.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var h := HBoxContainer.new()
	sp.add_child(h)
	spd_lbl = _label("0", 54, Color.WHITE, HORIZONTAL_ALIGNMENT_RIGHT)
	spd_lbl.custom_minimum_size = Vector2(100, 0)
	unit_lbl = _label("km/h", 16, Color(0.6, 0.66, 0.72), HORIZONTAL_ALIGNMENT_LEFT)
	h.add_child(spd_lbl)
	h.add_child(unit_lbl)
	root.add_child(sp)
	# score + drift, top left
	score_lbl = _label("", 16, Color(1, 1, 1, 0.85), HORIZONTAL_ALIGNMENT_LEFT)
	score_lbl.position = Vector2(16, 12)
	root.add_child(score_lbl)
	drift_lbl = _label("", 30, Color("f2b01e"))
	drift_lbl.set_anchors_preset(Control.PRESET_CENTER_TOP)
	drift_lbl.position = Vector2(-120, 90)
	drift_lbl.custom_minimum_size = Vector2(240, 0)
	root.add_child(drift_lbl)
	# network note
	net_lbl = _label("", 15, Color("ffd88a"))
	net_lbl.set_anchors_preset(Control.PRESET_CENTER_TOP)
	net_lbl.position = Vector2(-200, 50)
	net_lbl.custom_minimum_size = Vector2(400, 0)
	root.add_child(net_lbl)
	# toast
	toast_lbl = _label("", 26)
	toast_lbl.set_anchors_preset(Control.PRESET_CENTER)
	toast_lbl.position = Vector2(-300, -20)
	toast_lbl.custom_minimum_size = Vector2(600, 0)
	toast_lbl.modulate.a = 0.0
	root.add_child(toast_lbl)
	# buttons, bottom right
	var bb := HBoxContainer.new()
	bb.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	bb.position = Vector2(-16, -16)
	bb.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	bb.grow_vertical = Control.GROW_DIRECTION_BEGIN
	bb.add_theme_constant_override("separation", 8)
	bb.add_child(_button("خريطة مصر  M", func(): map_pressed.emit()))
	bb.add_child(_button("رجّعني للطريق  R", func(): reset_pressed.emit()))
	bb.add_child(_button("كاميرا  V", func(): view_pressed.emit()))
	bb.add_child(_button("لون  C", func(): color_pressed.emit()))
	root.add_child(bb)
	var hint := _label("للسواقة: W A S D   ·   للفرامل اليدوي: مسافة   ·   لخريطة مصر: M", 14, Color(1, 1, 1, 0.7))
	hint.text_direction = Control.TEXT_DIRECTION_RTL
	hint.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	hint.position = Vector2(-300, -78)
	hint.custom_minimum_size = Vector2(600, 0)
	hint.grow_vertical = Control.GROW_DIRECTION_BEGIN
	root.add_child(hint)


func _build_nav() -> void:
	nav_box = PanelContainer.new()
	nav_box.add_theme_stylebox_override("panel", _sb(PANEL, 10, 14))
	nav_box.set_anchors_preset(Control.PRESET_CENTER_TOP)
	nav_box.position = Vector2(-230, 8)
	nav_box.custom_minimum_size = Vector2(460, 0)
	nav_box.visible = false
	var v := VBoxContainer.new()
	nav_box.add_child(v)
	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 14)
	nav_arrow = _label("↑", 46, Color("37d5ff"))
	nav_arrow.custom_minimum_size = Vector2(58, 0)
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	nav_dist = _label("", 26, Color.WHITE, HORIZONTAL_ALIGNMENT_RIGHT)
	nav_txt = _label("", 17, Color(0.9, 0.95, 1.0), HORIZONTAL_ALIGNMENT_RIGHT)
	nav_txt.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	col.add_child(nav_dist)
	col.add_child(nav_txt)
	top.add_child(col)
	top.add_child(nav_arrow)
	v.add_child(top)
	nav_bar = ProgressBar.new()
	nav_bar.show_percentage = false
	nav_bar.custom_minimum_size = Vector2(0, 8)
	v.add_child(nav_bar)
	nav_sub = _label("", 14, Color(0.7, 0.78, 0.85), HORIZONTAL_ALIGNMENT_RIGHT)
	v.add_child(nav_sub)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	row.add_child(_button("إلغاء", func(): nav_cancel_pressed.emit()))
	row.add_child(_button("اقفز ٥ كم  J", func(): jump_pressed.emit()))
	row.add_child(_button("قرب الوجهة  K", func(): jump_near_pressed.emit()))
	nav_voice = _button("صوت", func(): pass)
	nav_voice.toggle_mode = true
	nav_voice.toggled.connect(func(on): voice_toggled.emit(on))
	row.add_child(nav_voice)
	v.add_child(row)
	root.add_child(nav_box)


func _build_start() -> void:
	start_box = PanelContainer.new()
	start_box.add_theme_stylebox_override("panel", _sb(Color(0.06, 0.08, 0.1, 0.94), 12, 26))
	start_box.set_anchors_preset(Control.PRESET_CENTER)
	start_box.custom_minimum_size = Vector2(620, 0)
	start_box.position = Vector2(-310, -210)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	start_box.add_child(v)
	var title := _label("Egypt Drive", 46, Color("f2b01e"))
	v.add_child(title)
	var lead := _label("تبدأ من دمياط الجديدة، على الشارع اللي فيه مستشفى كابيتال كير. الشوارع والمباني اللي هتسوق عليها حقيقية، متحمّلة من OpenStreetMap. افتح خريطة مصر ثلاثية الأبعاد (M) واختار أي وجهة.", 17, Color(0.9, 0.93, 0.96))
	lead.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	lead.custom_minimum_size = Vector2(560, 0)
	v.add_child(lead)
	start_msg = _label("", 16, Color(0.7, 0.78, 0.85))
	start_msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	start_msg.custom_minimum_size = Vector2(560, 0)
	v.add_child(start_msg)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	retry_btn = _button("حاول تاني", func(): retry_pressed.emit(), true)
	retry_btn.visible = false
	start_btn = _button("ابدأ السواقة", func(): start_pressed.emit(), true)
	start_btn.disabled = true
	start_btn.add_theme_stylebox_override("normal", _sb(GREEN, 8, 12))
	start_btn.add_theme_stylebox_override("hover", _sb(GREEN.lightened(0.12), 8, 12))
	row.add_child(retry_btn)
	row.add_child(start_btn)
	v.add_child(row)
	root.add_child(start_box)


func _build_arrive() -> void:
	arrive_box = PanelContainer.new()
	arrive_box.add_theme_stylebox_override("panel", _sb(Color(0.06, 0.08, 0.1, 0.94), 12, 26))
	arrive_box.set_anchors_preset(Control.PRESET_CENTER)
	arrive_box.custom_minimum_size = Vector2(440, 0)
	arrive_box.position = Vector2(-220, -90)
	arrive_box.visible = false
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	arrive_box.add_child(v)
	arrive_lbl = _label("", 24, Color("7be08a"))
	arrive_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	arrive_lbl.custom_minimum_size = Vector2(380, 0)
	v.add_child(arrive_lbl)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 10)
	row.add_child(_button("وجهة جديدة  M", func():
		arrive_box.visible = false
		map_pressed.emit()))
	row.add_child(_button("كمّل سواقة", func(): arrive_box.visible = false))
	v.add_child(row)
	root.add_child(arrive_box)


func _build_touch() -> void:
	var defs := [["◀", "left", Vector2(24, -215)], ["▶", "right", Vector2(120, -215)]]
	for d in defs:
		root.add_child(_touch_btn(d[0], d[1], d[2], true))
	var defs2 := [["■", "brake", Vector2(-290, -150)], ["≋", "hb", Vector2(-200, -150)], ["▲", "gas", Vector2(-110, -150)]]
	for d in defs2:
		root.add_child(_touch_btn(d[0], d[1], d[2], false))


func _touch_btn(txt: String, key: String, pos: Vector2, left: bool) -> Button:
	var b := _button(txt, func(): pass, true)
	b.custom_minimum_size = Vector2(80, 80)
	b.set_anchors_preset(Control.PRESET_BOTTOM_LEFT if left else Control.PRESET_BOTTOM_RIGHT)
	b.position = pos
	b.button_down.connect(func(): touch[key] = true)
	b.button_up.connect(func(): touch[key] = false)
	return b


func _process(delta: float) -> void:
	if _toast_t > 0.0:
		_toast_t -= delta
		toast_lbl.modulate.a = clampf(_toast_t * 2.0, 0.0, 1.0)


func toast(msg: String) -> void:
	toast_lbl.text = msg
	_toast_t = 2.6
	toast_lbl.modulate.a = 1.0


func show_start(msg: String, can_start: bool, can_retry: bool, err: bool = false) -> void:
	start_box.visible = true
	start_msg.text = msg
	start_msg.add_theme_color_override("font_color", Color("ff9a8f") if err else Color(0.7, 0.78, 0.85))
	start_btn.disabled = not can_start
	retry_btn.visible = can_retry


func hide_start() -> void:
	start_box.visible = false


func show_arrive(name: String) -> void:
	arrive_lbl.text = "وصلت! " + name
	arrive_box.visible = true
