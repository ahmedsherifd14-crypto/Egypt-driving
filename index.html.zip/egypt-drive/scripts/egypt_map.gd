class_name EgyptMap
extends Node3D
## A 3D model of Egypt: the real national border (OpenStreetMap, fetched at run time), the 28 cities, optionally the real
## motorways and trunk roads, and your route. Pick a destination by clicking the model, the list, or the search box.
## 1 unit = 10 km.

signal closed
signal drive_requested(dest: Dictionary, mode: String)

const UNIT_KM := 10.0
const REF_LAT := 27.0
const REF_LON := 30.8
const TOP_Y := 0.4
const PRIO := ["القاهرة", "الإسكندرية", "أسوان", "الأقصر", "شرم الشيخ", "الغردقة", "بورسعيد", "السويس", "دمياط", "المنصورة", "أسيوط", "مرسى مطروح", "الإسماعيلية", "طنطا", "الفيوم", "المنيا", "سوهاج"]

var cam: Camera3D
var ui: CanvasLayer
var theme_: Theme
var _yaw: float = 0.0
var _pitch: float = 1.08
var _dist: float = 235.0
var _target := Vector3(11.0, TOP_Y, 2.0)
var _labels: Array = []
var _drag_start := Vector2.ZERO
var _dragging: bool = false
var _moved: float = 0.0
var _rings: Array = []          # border rings in map units (Vector2 x, z)
var _border_ok: bool = false
var _land: MeshInstance3D
var _dest_mk: MeshInstance3D
var _car_mk: MeshInstance3D
var _route_mi: MeshInstance3D
var _hw_mi: MeshInstance3D
var _hw_state: int = 0          # 0 not loaded, 1 loading, 2 shown, 3 hidden
var _pins: Node3D
var _nav: Nav
var _dest: Dictionary = {}
var _route: Dictionary = {}
var _car_ll := Vector2(31.43, 31.70)
var _busy: bool = false
var _opened_once: bool = false
# ui
var _q: LineEdit
var _res: VBoxContainer
var _sel: OptionButton
var _info: Label
var _sum: Label
var _status: Label
var _near: CheckBox
var _pan_cb: CheckBox
var _btn_route: Button
var _btn_drive: Button
var _btn_hw: Button


func _ready() -> void:
	cam = Camera3D.new()
	cam.fov = 40.0
	cam.near = 1.0
	cam.far = 1500.0
	add_child(cam)
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.04, 0.09, 0.14)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.75, 0.8, 0.9)
	env.ambient_light_energy = 0.9
	cam.environment = env       # the camera's own environment wins over the game's WorldEnvironment
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, -30, 0)
	sun.light_energy = 1.1
	add_child(sun)
	var sea := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(900, 900)
	sea.mesh = pm
	var sm := StandardMaterial3D.new()
	sm.albedo_color = Color(0.1, 0.32, 0.5)
	sm.roughness = 0.35
	sm.metallic = 0.2
	sea.material_override = sm
	sea.position.y = -0.1
	add_child(sea)
	_pins = Node3D.new()
	add_child(_pins)
	_nav = Nav.new()
	_build_ui()
	_build_cities()
	_update_camera()
	set_process(false)
	set_process_unhandled_input(false)


func _exit_tree() -> void:
	if _nav != null and not _nav.is_inside_tree():
		_nav.free()


# ------------------------------------------------------------------ projection (map units)
func ll_to_map(lat: float, lon: float) -> Vector2:
	var kx := 111.32 * cos(deg_to_rad(REF_LAT)) / UNIT_KM
	var ky := 111.13 / UNIT_KM
	return Vector2((lon - REF_LON) * kx, -(lat - REF_LAT) * ky)


func map_to_ll(p: Vector2) -> Vector2:
	var kx := 111.32 * cos(deg_to_rad(REF_LAT)) / UNIT_KM
	var ky := 111.13 / UNIT_KM
	return Vector2(REF_LAT - p.y / ky, REF_LON + p.x / kx)


func _inside_egypt(p: Vector2) -> bool:
	if not _border_ok:
		return true
	for r in _rings:
		if Geometry2D.is_point_in_polygon(p, r):
			return true
	return false


# ------------------------------------------------------------------ open / close
func open(car_pos: Vector2, route: Dictionary, dest_name: String) -> void:
	visible = true
	_car_ll = Geo.unproj(car_pos)
	cam.make_current()
	ui.visible = true
	set_process(true)
	set_process_unhandled_input(true)
	_place_marker(_car_mk_get(), _car_ll, 0.9)
	if not route.is_empty():
		_show_route(route.ll)
		var e: Vector2 = route.ll[route.ll.size() - 1]
		_set_dest(e.x, e.y, dest_name, false)
	if not _opened_once:
		_opened_once = true
		_load_border()


func close() -> void:
	visible = false
	ui.visible = false
	set_process(false)
	set_process_unhandled_input(false)


func _car_mk_get() -> MeshInstance3D:
	if _car_mk == null:
		_car_mk = _marker(Color(0.95, 0.7, 0.1), 0.5, 1.6)
		add_child(_car_mk)
	return _car_mk


func _marker(col: Color, r: float, h: float) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	var c := CylinderMesh.new()
	c.top_radius = 0.0
	c.bottom_radius = r
	c.height = h
	m.mesh = c
	var mat := StandardMaterial3D.new()
	mat.albedo_color = col
	mat.emission_enabled = true
	mat.emission = col
	mat.emission_energy_multiplier = 0.6
	m.material_override = mat
	return m


func _place_marker(m: MeshInstance3D, ll: Vector2, lift: float) -> void:
	var p := ll_to_map(ll.x, ll.y)
	m.position = Vector3(p.x, TOP_Y + lift, p.y)
	m.rotation.x = PI      # a pin pointing down at the spot


# ------------------------------------------------------------------ border and land
func _load_border() -> void:
	_set_status("بحمّل حدود مصر الحقيقية…")
	var gj: Variant = null
	var cache := "user://cache/egypt_border.json"
	if not Cfg.custom and FileAccess.file_exists(cache):
		gj = JSON.parse_string(FileAccess.get_file_as_string(cache))
	if gj == null:
		var j: Variant = await Net.get_json("%s/search?q=Egypt&format=jsonv2&polygon_geojson=1&polygon_threshold=0.01&limit=1&featuretype=country&accept-language=en" % Cfg.nominatim, 30.0)
		if j is Array and j.size() > 0 and (j[0] as Dictionary).has("geojson"):
			gj = j[0]["geojson"]
			if not Cfg.custom:
				DirAccess.make_dir_recursive_absolute("user://cache")
				var f := FileAccess.open(cache, FileAccess.WRITE)
				if f != null:
					f.store_string(JSON.stringify(gj))
	if not (gj is Dictionary):
		_set_status("مقدرتش أحمّل حدود مصر (محتاج إنترنت). الخريطة شغالة بس من غير شكل البلد.")
		return
	var polys: Array = []
	if gj.type == "Polygon":
		polys = [gj.coordinates]
	elif gj.type == "MultiPolygon":
		polys = gj.coordinates
	_rings.clear()
	for poly in polys:
		var ring := PackedVector2Array()
		for c in poly[0]:
			ring.append(ll_to_map(c[1], c[0]))
		ring = Osm.clean_ring(ring)
		if ring.size() >= 3 and absf(Geo.poly_area(ring)) > 0.15:
			_rings.append(ring)
	_build_land()
	_border_ok = _rings.size() > 0
	_set_status("" if _border_ok else "شكل الحدود مش واضح.")


func _build_land() -> void:
	if _land != null:
		_land.queue_free()
	var mb := Osm.MB.new(0.0, 0.0)
	var top := Color(0.84, 0.74, 0.52)
	var side := Color(0.5, 0.42, 0.28)
	for ring in _rings:
		var r: PackedVector2Array = ring
		Osm.fill_poly(mb, r, TOP_Y, top)
		var rr: PackedVector2Array = r.duplicate()
		if Geo.poly_area(rr) < 0.0:
			rr.reverse()
		var n := rr.size()
		for i in n:
			var p := rr[i]
			var q := rr[(i + 1) % n]
			var d := q - p
			var l := d.length()
			if l < 0.0001:
				continue
			var nrm := Vector3(d.y / l, 0, -d.x / l)
			var i0 := mb.vert(p.x, -0.1, p.y, nrm, side, 0, 0)
			var i1 := mb.vert(q.x, -0.1, q.y, nrm, side, 0, 0)
			var i2 := mb.vert(p.x, TOP_Y, p.y, nrm, side, 0, 0)
			var i3 := mb.vert(q.x, TOP_Y, q.y, nrm, side, 0, 0)
			mb.tri(i0, i1, i3, nrm)
			mb.tri(i0, i3, i2, nrm)
	if mb.is_empty():
		return
	var m := ArrayMesh.new()
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, mb.arrays())
	_land = MeshInstance3D.new()
	_land.mesh = m
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 0.9
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	_land.material_override = mat
	add_child(_land)


func _build_cities() -> void:
	var f: Font = load("res://fonts/DejaVuSans.ttf")
	for c in Cfg.CITIES:
		var p := ll_to_map(c[1], c[2])
		var pin := MeshInstance3D.new()
		var sp := SphereMesh.new()
		sp.radius = 0.4
		sp.height = 0.8
		pin.mesh = sp
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(0.9, 0.25, 0.2)
		pin.material_override = mat
		pin.position = Vector3(p.x, TOP_Y + 0.15, p.y)
		_pins.add_child(pin)
		var lb := Label3D.new()
		lb.text = c[0]
		lb.font = f
		lb.font_size = 26
		lb.pixel_size = 0.0011
		lb.fixed_size = true
		lb.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		lb.no_depth_test = true
		lb.outline_size = 8
		lb.modulate = Color(1, 1, 1)
		lb.outline_modulate = Color(0, 0, 0, 0.85)
		lb.position = Vector3(p.x, TOP_Y + 1.0, p.y)
		_pins.add_child(lb)
		var pr := PRIO.find(c[0])
		_labels.append({"lb": lb, "len": str(c[0]).length(), "prio": pr if pr >= 0 else 100 + _labels.size()})
	_labels.sort_custom(func(a, b): return a.prio < b.prio)


# ------------------------------------------------------------------ real motorways (optional overlay)
func _toggle_highways() -> void:
	if _hw_state == 1:
		return
	if _hw_state == 2:
		_hw_mi.visible = false
		_hw_state = 3
		_btn_hw.text = "اعرض الطرق الرئيسية"
		return
	if _hw_state == 3:
		_hw_mi.visible = true
		_hw_state = 2
		_btn_hw.text = "اخفي الطرق الرئيسية"
		return
	_hw_state = 1
	_btn_hw.disabled = true
	_set_status("بحمّل الطرق السريعة الحقيقية لكل مصر (ممكن تاخد دقيقة)…")
	var path := "user://cache/egypt_highways.gz"
	var text := ""
	if not Cfg.custom and FileAccess.file_exists(path):
		var f := FileAccess.open_compressed(path, FileAccess.READ, FileAccess.COMPRESSION_GZIP)
		if f != null:
			text = f.get_as_text()
	if not text.begins_with("{"):
		var q := '[out:json][timeout:120];way["highway"~"^(motorway|trunk)$"](21.5,24.5,32.0,37.2);out geom qt;'
		text = await Net.overpass_text(q)
		if text != "" and not Cfg.custom:
			DirAccess.make_dir_recursive_absolute("user://cache")
			var wf := FileAccess.open_compressed(path, FileAccess.WRITE, FileAccess.COMPRESSION_GZIP)
			if wf != null:
				wf.store_string(text)
	if text == "":
		_hw_state = 0
		_btn_hw.disabled = false
		_set_status("مقدرتش أحمّل الطرق السريعة. جرّب تاني بعد شوية.")
		return
	var tid := WorkerThreadPool.add_task(_hw_work.bind(text))
	while not WorkerThreadPool.is_task_completed(tid):
		await get_tree().create_timer(0.1).timeout
	WorkerThreadPool.wait_for_task_completion(tid)
	var arrays: Array = _hw_result
	if arrays.is_empty():
		_hw_state = 0
		_btn_hw.disabled = false
		_set_status("الرد مكانش فيه طرق.")
		return
	var m := ArrayMesh.new()
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	_hw_mi = MeshInstance3D.new()
	_hw_mi.mesh = m
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.vertex_color_use_as_albedo = true
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	_hw_mi.material_override = mat
	add_child(_hw_mi)
	_hw_state = 2
	_btn_hw.disabled = false
	_btn_hw.text = "اخفي الطرق الرئيسية"
	_set_status("")


var _hw_result: Array = []


func _hw_work(text: String) -> void:
	_hw_result = []
	var parsed: Variant = JSON.parse_string(text)
	if not (parsed is Dictionary):
		return
	var mb := Osm.MB.new(0.0, 0.0)
	var col := Color(1.0, 0.62, 0.15)
	for e in parsed.get("elements", []):
		if not e.has("geometry"):
			continue
		var pts := PackedVector2Array()
		for q in e["geometry"]:
			if q != null:
				pts.append(ll_to_map(q["lat"], q["lon"]))
		if pts.size() < 2:
			continue
		pts = Geo.simplify(pts, 0.02)
		Osm.ribbon(mb, pts, 0.1, TOP_Y + 0.05, col, 0.0)
	if not mb.is_empty():
		_hw_result = mb.arrays()


# ------------------------------------------------------------------ destination and route
func _set_dest(lat: float, lon: float, nm: String, fly: bool = true) -> void:
	_dest = {"lat": lat, "lon": lon, "name": nm}
	if _dest_mk == null:
		_dest_mk = _marker(Color(0.2, 0.75, 1.0), 0.45, 2.6)
		add_child(_dest_mk)
	_place_marker(_dest_mk, Vector2(lat, lon), 1.5)
	_info.text = "%s  ·  %.4f,%.4f" % [nm if nm != "" else "الوجهة", lat, lon]
	_btn_route.disabled = false
	_btn_drive.disabled = false
	_sum.text = ""
	_clear_route()
	if fly:
		var p := ll_to_map(lat, lon)
		_target = Vector3(p.x, TOP_Y, p.y)
		_update_camera()
	if nm == "":
		var tk := _dest
		var r := await Net.reverse_name(lat, lon, 12)
		if _dest == tk and r.has("full") and r.full != "":
			var parts: PackedStringArray = str(r.full).split("،") if str(r.full).contains("،") else str(r.full).split(",")
			tk["name"] = ", ".join(parts.slice(0, 3)) if parts.size() > 0 else "الوجهة"
			_info.text = "%s  ·  %.4f,%.4f" % [tk.name, lat, lon]


func _clear_route() -> void:
	if _route_mi != null:
		_route_mi.queue_free()
		_route_mi = null
	_route = {}


func _show_route(ll: PackedVector2Array) -> void:
	if _route_mi != null:
		_route_mi.queue_free()
	var pts := PackedVector2Array()
	for p in ll:
		pts.append(ll_to_map(p.x, p.y))
	pts = Geo.simplify(pts, 0.01)
	var mb := Osm.MB.new(0.0, 0.0)
	Osm.ribbon(mb, pts, 0.22, TOP_Y + 0.12, Color(0.2, 0.8, 1.0), 0.0)
	if mb.is_empty():
		return
	var m := ArrayMesh.new()
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, mb.arrays())
	_route_mi = MeshInstance3D.new()
	_route_mi.mesh = m
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.vertex_color_use_as_albedo = true
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	_route_mi.material_override = mat
	add_child(_route_mi)


func _preview_route() -> void:
	if _dest.is_empty() or _busy:
		return
	_busy = true
	_btn_route.disabled = true
	_sum.text = "بحسب الطريق…"
	var R := await _nav.fetch_route(_car_ll, Vector2(_dest.lat, _dest.lon))
	_busy = false
	_btn_route.disabled = false
	if R.is_empty():
		_sum.text = "⚠ " + _nav.err
		return
	_route = R
	_show_route(R.ll)
	_sum.text = "المسافة %s  ·  الوقت التقريبي %s" % [Geo.fmt_dist(R.total), Geo.fmt_time(R.dur)]


func _drive() -> void:
	if _dest.is_empty():
		return
	drive_requested.emit(_dest, "near" if _near.button_pressed else "here")


# ------------------------------------------------------------------ camera and input
func _update_camera() -> void:
	var dir := Vector3(cos(_pitch) * sin(_yaw), sin(_pitch), cos(_pitch) * cos(_yaw))
	cam.position = _target + dir * _dist
	cam.look_at(_target, Vector3.UP)


func _process(_dt: float) -> void:
	_update_camera()
	_declutter()


## show a city name only when it does not overlap a more important one already shown
func _declutter() -> void:
	var taken: Array = []
	for it in _labels:
		var lb: Label3D = it.lb
		if cam.is_position_behind(lb.global_position):
			lb.visible = false
			continue
		var sp := cam.unproject_position(lb.global_position)
		var w := float(it.len) * 17.0 + 14.0
		var r := Rect2(sp - Vector2(w / 2.0, 14.0), Vector2(w, 28.0))
		var ok := true
		for t in taken:
			if (t as Rect2).intersects(r):
				ok = false
				break
		lb.visible = ok
		if ok:
			taken.append(r)


func _unhandled_input(e: InputEvent) -> void:
	if not visible:
		return
	var mb := e as InputEventMouseButton
	if mb != null:
		if mb.button_index == MOUSE_BUTTON_WHEEL_UP and mb.pressed:
			_dist = clampf(_dist * 0.9, 12.0, 320.0)
		elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN and mb.pressed:
			_dist = clampf(_dist * 1.1, 12.0, 320.0)
		elif mb.button_index == MOUSE_BUTTON_LEFT or mb.button_index == MOUSE_BUTTON_RIGHT or mb.button_index == MOUSE_BUTTON_MIDDLE:
			if mb.pressed:
				_dragging = true
				_drag_start = mb.position
				_moved = 0.0
			else:
				if _dragging and _moved < 6.0 and mb.button_index == MOUSE_BUTTON_LEFT:
					_pick(mb.position)
				_dragging = false
	var mm := e as InputEventMouseMotion
	if mm != null and _dragging:
		_moved += mm.relative.length()
		if (mm.button_mask & MOUSE_BUTTON_MASK_LEFT) != 0 and not Input.is_key_pressed(KEY_SHIFT) and not _pan_cb.button_pressed:
			_yaw -= mm.relative.x * 0.006
			_pitch = clampf(_pitch + mm.relative.y * 0.006, 0.2, 1.52)
		else:
			var k := _dist * 0.0016
			var right := Vector3(cos(_yaw), 0, -sin(_yaw))
			var fwd := Vector3(-sin(_yaw), 0, -cos(_yaw))
			_target += (-right * mm.relative.x + fwd * mm.relative.y) * k
	if e is InputEventKey and e.pressed and not e.echo and e.physical_keycode == KEY_ESCAPE:
		closed.emit()
	if e is InputEventKey and e.pressed and not e.echo and e.physical_keycode == KEY_M:
		closed.emit()


func _pick(pos: Vector2) -> void:
	var o := cam.project_ray_origin(pos)
	var d := cam.project_ray_normal(pos)
	if absf(d.y) < 0.0001:
		return
	var t := (TOP_Y - o.y) / d.y
	if t < 0.0:
		return
	var hit := o + d * t
	var p := Vector2(hit.x, hit.z)
	if not _inside_egypt(p):
		_set_status("المكان ده برا حدود مصر. اضغط جوّه البلد.")
		return
	_set_status("")
	var ll := map_to_ll(p)
	_set_dest(ll.x, ll.y, "", false)


func _zoom(f: float) -> void:
	_dist = clampf(_dist * f, 12.0, 320.0)


func _set_status(t: String) -> void:
	if _status != null:
		_status.text = t


# ------------------------------------------------------------------ UI
func _sb(color: Color, radius: int = 8, pad: int = 10) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = color
	s.set_corner_radius_all(radius)
	s.content_margin_left = pad
	s.content_margin_right = pad
	s.content_margin_top = pad * 0.6
	s.content_margin_bottom = pad * 0.6
	return s


func _btn(text: String, cb: Callable, main: bool = false) -> Button:
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_stylebox_override("normal", _sb(Color(0.3, 0.69, 0.31) if main else Color(0.2, 0.22, 0.26), 6, 10))
	b.add_theme_stylebox_override("hover", _sb(Color(0.27, 0.63, 0.28) if main else Color(0.28, 0.31, 0.36), 6, 10))
	b.add_theme_stylebox_override("disabled", _sb(Color(0.15, 0.16, 0.18), 6, 10))
	b.pressed.connect(cb)
	return b


func _lbl(text: String, size: int = 15, color: Color = Color.WHITE) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	return l


func _build_ui() -> void:
	ui = CanvasLayer.new()
	ui.layer = 8
	ui.visible = false
	add_child(ui)
	theme_ = Theme.new()
	var f: Font = load("res://fonts/DejaVuSans.ttf")
	theme_.default_font = f
	theme_.default_font_size = 16
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.theme = theme_
	ui.add_child(root)
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _sb(Color(0, 0, 0, 0.87), 12, 14))
	panel.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	panel.position = Vector2(-12, 12)
	panel.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	panel.custom_minimum_size = Vector2(350, 0)
	root.add_child(panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 7)
	panel.add_child(v)
	var title := _lbl("اختار وجهتك في مصر", 20, Color("4CAF50"))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(title)
	var row := HBoxContainer.new()
	_q = LineEdit.new()
	_q.placeholder_text = "ابحث عن مكان أو شارع…"
	_q.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_q.text_submitted.connect(func(_t): _search())
	row.add_child(_q)
	row.add_child(_btn("بحث", _search))
	v.add_child(row)
	_res = VBoxContainer.new()
	v.add_child(_res)
	v.add_child(_lbl("اختر وجهتك:", 14, Color(0.8, 0.84, 0.88)))
	_sel = OptionButton.new()
	_sel.add_item("اختار مدينة…")
	for c in Cfg.CITIES:
		_sel.add_item(c[0])
	_sel.item_selected.connect(func(i):
		if i > 0:
			var c: Array = Cfg.CITIES[i - 1]
			_set_dest(c[1], c[2], c[0]))
	v.add_child(_sel)
	_info = _lbl("اضغط على نموذج مصر لتحديد الوجهة، أو ابحث، أو اختار مدينة.", 14)
	v.add_child(_info)
	_near = CheckBox.new()
	_near.text = "ابدأ قرب الوجهة (٣ كم قبلها)"
	v.add_child(_near)
	_btn_route = _btn("ارسم الطريق", _preview_route, true)
	_btn_route.disabled = true
	v.add_child(_btn_route)
	_sum = _lbl("", 15, Color(0.45, 0.85, 1.0))
	v.add_child(_sum)
	_btn_drive = _btn("ابدأ التوجيه وسوق", _drive, true)
	_btn_drive.disabled = true
	v.add_child(_btn_drive)
	_btn_hw = _btn("اعرض الطرق الرئيسية", _toggle_highways)
	v.add_child(_btn_hw)
	_pan_cb = CheckBox.new()
	_pan_cb.text = "وضع التحريك (للمس: السحب يحرّك الخريطة)"
	v.add_child(_pan_cb)
	var zr := HBoxContainer.new()
	zr.add_child(_btn("+", func(): _zoom(0.8)))
	zr.add_child(_btn("-", func(): _zoom(1.25)))
	zr.add_child(_btn("رجوع للسواقة  M", func(): closed.emit()))
	v.add_child(zr)
	_status = _lbl("", 13, Color("ffd88a"))
	v.add_child(_status)
	v.add_child(_lbl("اسحب للدوران (أو للتحريك لو وضع التحريك شغّال)، Shift + سحب للتحريك، العجلة أو + و − للتقريب، اضغط لتحديد الوجهة. الحدود والطرق من OpenStreetMap.", 12, Color(0.6, 0.66, 0.72)))


func _search() -> void:
	var q := _q.text.strip_edges()
	if q.length() < 2:
		return
	for c in _res.get_children():
		c.queue_free()
	var wait := _lbl("بدوّر…", 14)
	_res.add_child(wait)
	var r := await Net.geocode(q, 6)
	wait.queue_free()
	if r.is_empty():
		_res.add_child(_lbl("ملقيتش نتيجة. جرّب اسم تاني أو اضغط على النموذج.", 14))
		return
	for it in r:
		var nm: String = it.name
		var parts: PackedStringArray = nm.split("،") if nm.contains("،") else nm.split(",")
		var short := ", ".join(parts.slice(0, 3))
		var b := _btn(short, func():
			for c in _res.get_children():
				c.queue_free()
			_set_dest(it.lat, it.lon, short))
		b.alignment = HORIZONTAL_ALIGNMENT_RIGHT
		_res.add_child(b)
