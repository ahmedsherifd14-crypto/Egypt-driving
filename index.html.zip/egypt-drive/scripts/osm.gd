class_name Osm
extends RefCounted
## Real OpenStreetMap data -> game data and mesh arrays for one grid cell.
## `process()` is pure (no scene access), so it can run on a worker thread.

const CELL := 0.015
const SEA_W := 900.0
const UP := Vector3(0, 1, 0)

# [default width in m, rank]
const HW := {
	"motorway": [13.0, 6], "motorway_link": [7.0, 5], "trunk": [12.0, 6], "trunk_link": [7.0, 5],
	"primary": [10.5, 5], "primary_link": [6.5, 4], "secondary": [9.0, 4], "secondary_link": [6.0, 3],
	"tertiary": [8.0, 3], "tertiary_link": [6.0, 3], "unclassified": [6.5, 2], "residential": [6.5, 2],
	"living_street": [5.0, 2], "service": [4.2, 1], "track": [3.4, 0], "road": [6.0, 2],
}
const HWNAME := {
	"motorway": "الطريق السريع", "motorway_link": "مدخل الطريق السريع", "trunk": "طريق سريع", "trunk_link": "مدخل طريق سريع",
	"primary": "طريق رئيسي", "primary_link": "مدخل طريق رئيسي", "secondary": "طريق رئيسي فرعي", "secondary_link": "مدخل طريق",
	"tertiary": "شارع رئيسي", "tertiary_link": "مدخل شارع", "unclassified": "شارع بدون اسم", "residential": "شارع جانبي",
	"living_street": "شارع جانبي", "service": "طريق خدمة", "track": "طريق ترابي", "road": "طريق",
}
const BCOL := ["#e8dcc4", "#d9c7a3", "#cdb48b", "#efe7d6", "#d8a982", "#b98d66", "#f1ebdd", "#c9b49a", "#e3cfae", "#bfae96", "#e6c9a0", "#d6b98c"]
const BROOF := ["#a9a396", "#b3ab9b", "#9d9689", "#bdb5a6"]
const SKIP_HW := "^(footway|path|steps|cycleway|bridleway|corridor|proposed|construction|pedestrian|elevator|platform|raceway)$"


static func query_for(ci: int, cj: int) -> String:
	var s := cj * CELL
	var w := ci * CELL
	var b := "(%s,%s,%s,%s)" % [String.num(s, 5), String.num(w, 5), String.num(s + CELL, 5), String.num(w + CELL, 5)]
	return ("[out:json][timeout:30];(" +
		'way["highway"]["highway"!~"' + SKIP_HW + '"]' + b + ";" +
		'way["building"]' + b + ";" +
		'way["natural"~"^(water|coastline|wood|scrub|sand|beach|wetland|bare_rock)$"]' + b + ";" +
		'way["waterway"~"^(river|canal|stream|drain|riverbank)$"]' + b + ";" +
		'way["landuse"~"^(residential|commercial|retail|industrial|farmland|farmyard|meadow|grass|forest|orchard|vineyard|cemetery|military|construction|basin|reservoir|allotments|greenhouse_horticulture)$"]' + b + ";" +
		'way["leisure"~"^(park|garden|pitch|playground|stadium|golf_course|nature_reserve)$"]' + b + ";" +
		'rel["natural"="water"]["water"!~"^(river|canal|stream)$"]' + b + ";);out geom qt;")


# ------------------------------------------------------------------ mesh accumulator
class MB:
	var v := PackedVector3Array()
	var n := PackedVector3Array()
	var c := PackedColorArray()
	var uv := PackedVector2Array()
	var idx := PackedInt32Array()
	var ax: float = 0.0
	var az: float = 0.0

	func _init(cx: float, cz: float) -> void:
		ax = cx
		az = cz

	func vert(x: float, y: float, z: float, nrm: Vector3, col: Color, u: float, w: float) -> int:
		v.append(Vector3(x - ax, y, z - az))
		n.append(nrm)
		c.append(col)
		uv.append(Vector2(u, w))
		return v.size() - 1

	## Godot's front faces are clockwise, so order the triangle to face `nrm`.
	func tri(a: int, b: int, d: int, nrm: Vector3) -> void:
		var g := (v[b] - v[a]).cross(v[d] - v[a])
		if g.dot(nrm) > 0.0:
			idx.append(a)
			idx.append(d)
			idx.append(b)
		else:
			idx.append(a)
			idx.append(b)
			idx.append(d)

	func is_empty() -> bool:
		return idx.size() == 0

	func arrays() -> Array:
		var a: Array = []
		a.resize(Mesh.ARRAY_MAX)
		a[Mesh.ARRAY_VERTEX] = v
		a[Mesh.ARRAY_NORMAL] = n
		a[Mesh.ARRAY_COLOR] = c
		a[Mesh.ARRAY_TEX_UV] = uv
		a[Mesh.ARRAY_INDEX] = idx
		return a


# ------------------------------------------------------------------ tag knowledge
static func oneway_of(t: Dictionary) -> int:
	var v: String = str(t.get("oneway", ""))
	if v == "-1" or v == "reverse":
		return -1
	if v == "yes" or v == "true" or v == "1":
		return 1
	if v == "no":
		return 0
	var hw: String = str(t.get("highway", ""))
	if str(t.get("junction", "")) == "roundabout" or hw == "motorway" or hw == "motorway_link":
		return 1
	return 0


static func road_width(t: Dictionary, def: Array, ow: int) -> float:
	var w: float = def[0]
	var wt := str(t.get("width", "")).to_float()
	if wt > 1.0 and wt < 40.0:
		return wt
	var ln := str(t.get("lanes", "")).to_int()
	if ln > 0 and ln < 10:
		w = maxf(3.2, ln * 3.3 + (0.0 if ow != 0 else 0.2))
	elif ow != 0 and w > 9.0:
		w = maxf(6.5, w * 0.62)
	return clampf(w, 3.0, 26.0)


static func bld_height(t: Dictionary, id: int) -> float:
	var hh := str(t.get("height", "")).to_float()
	if not (hh > 0.0):
		var lv := str(t.get("building:levels", "")).to_float()
		if lv > 0.0:
			hh = lv * 3.1 + 1.0
	if not (hh > 0.0):
		var k: String = str(t.get("building", ""))
		if k in ["house", "detached", "semidetached_house", "hut", "cabin", "shed", "garage", "garages", "carport", "roof", "kiosk", "farm_auxiliary", "barn", "stable", "service", "container", "greenhouse", "bungalow", "terrace"]:
			hh = 3.2 + Geo.hash3(id, 1, 3) * 2.2
		elif k in ["commercial", "retail", "industrial", "warehouse", "supermarket", "hangar", "factory", "manufacture"]:
			hh = 6.0 + Geo.hash3(id, 2, 3) * 4.0
		elif k in ["hospital", "school", "university", "college", "mosque", "church", "public", "civic", "government", "hotel"]:
			hh = 11.0 + Geo.hash3(id, 3, 3) * 7.0
		else:
			hh = 12.5 + floorf(Geo.hash3(id, 4, 3) * 5.0) * 3.1
	return clampf(hh, 2.8, 160.0)


## [kind, hex colour, layer] or an empty array
static func area_style(t: Dictionary) -> Array:
	var lu: String = str(t.get("landuse", ""))
	var nt: String = str(t.get("natural", ""))
	var ls: String = str(t.get("leisure", ""))
	if nt == "water" or str(t.get("waterway", "")) == "riverbank" or lu == "basin" or lu == "reservoir" or t.has("water"):
		return ["water", "#2f86b5", 0]
	if lu in ["farmland", "allotments", "greenhouse_horticulture", "farmyard"]:
		return ["land", "#a3b76e", 1]
	if lu in ["orchard", "vineyard", "plant_nursery"]:
		return ["land", "#82a657", 1]
	if lu == "meadow" or lu == "grass":
		return ["land", "#93b26b", 1]
	if lu == "forest" or nt == "wood":
		return ["land", "#557f48", 1]
	if nt == "scrub":
		return ["land", "#a3aa72", 1]
	if nt == "wetland":
		return ["land", "#8aa78a", 1]
	if ls in ["park", "garden", "golf_course", "nature_reserve"]:
		return ["land", "#7aa95b", 1]
	if ls == "pitch":
		return ["land", "#8aa65f", 2]
	if ls == "playground":
		return ["land", "#d6c29a", 2]
	if ls == "stadium":
		return ["land", "#cfc7b4", 2]
	if lu == "residential":
		return ["land", "#dcd2bb", 0]
	if lu == "commercial" or lu == "retail":
		return ["land", "#d6cbb7", 0]
	if lu == "industrial":
		return ["land", "#c9c1b2", 0]
	if lu == "cemetery":
		return ["land", "#bfb69f", 0]
	if lu == "military" or lu == "construction":
		return ["land", "#cdb98f", 0]
	if nt == "sand" or nt == "beach":
		return ["land", "#e6d2a0", 0]
	if nt == "bare_rock":
		return ["land", "#c3b394", 0]
	return []


static func road_color(rank: int, cls: String) -> Color:
	if cls == "track":
		return Geo.lin("#9a8660")
	if rank >= 5:
		return Geo.lin("#5c5f64")
	if rank >= 3:
		return Geo.lin("#64676c")
	return Geo.lin("#6c6f74")


# ------------------------------------------------------------------ geometry helpers
static func in_cell(ci: int, cj: int, lat: float, lon: float) -> bool:
	return floori(lon / CELL) == ci and floori(lat / CELL) == cj


static func clean_ring(p: PackedVector2Array) -> PackedVector2Array:
	var out := PackedVector2Array()
	for q in p:
		if out.size() == 0 or out[out.size() - 1].distance_squared_to(q) > 0.0004:
			out.append(q)
	if out.size() > 1 and out[0].distance_squared_to(out[out.size() - 1]) < 0.0004:
		out.remove_at(out.size() - 1)
	return out


static func ring_box(p: PackedVector2Array) -> Rect2:
	var mn := Vector2(1e18, 1e18)
	var mx := Vector2(-1e18, -1e18)
	for q in p:
		mn = Vector2(minf(mn.x, q.x), minf(mn.y, q.y))
		mx = Vector2(maxf(mx.x, q.x), maxf(mx.y, q.y))
	return Rect2(mn, mx - mn)


static func ribbon(mb: MB, pts: PackedVector2Array, w: float, y: float, col: Color, mark: float, vscale: float = 1.0) -> void:
	var n := pts.size()
	if n < 2:
		return
	var hw := w / 2.0
	var cum := 0.0
	var base := mb.v.size()
	var cc := Color(col.r, col.g, col.b, mark)
	for i in n:
		var t := Vector2.ZERO
		var m := 1.0
		if i == 0:
			t = (pts[1] - pts[0]).normalized()
		elif i == n - 1:
			t = (pts[i] - pts[i - 1]).normalized()
		else:
			var t1 := (pts[i] - pts[i - 1]).normalized()
			var t2 := (pts[i + 1] - pts[i]).normalized()
			t = (t1 + t2)
			if t.length() < 0.01:
				t = t2
			t = t.normalized()
			m = 1.0 / maxf(0.45, t.dot(t2))
		if i > 0:
			cum += pts[i].distance_to(pts[i - 1])
		var nr := Vector2(-t.y, t.x) * hw * minf(m, 2.2)
		mb.vert(pts[i].x + nr.x, y, pts[i].y + nr.y, UP, cc, 0.0, cum * vscale)
		mb.vert(pts[i].x - nr.x, y, pts[i].y - nr.y, UP, cc, 1.0, cum * vscale)
	for i in n - 1:
		var a := base + i * 2
		mb.tri(a, a + 2, a + 1, UP)
		mb.tri(a + 2, a + 3, a + 1, UP)


static func fill_poly(mb: MB, pts: PackedVector2Array, y: float, col: Color) -> void:
	if pts.size() < 3:
		return
	var tr := Geometry2D.triangulate_polygon(pts)
	if tr.is_empty():
		return
	var base := mb.v.size()
	for p in pts:
		mb.vert(p.x, y, p.y, UP, col, 0.0, -1.0)
	for k in range(0, tr.size(), 3):
		mb.tri(base + tr[k], base + tr[k + 1], base + tr[k + 2], UP)


static func quad_up(mb: MB, a: Vector2, b: Vector2, c: Vector2, d: Vector2, y: float, col: Color) -> void:
	var i0 := mb.vert(a.x, y, a.y, UP, col, 0.0, -1.0)
	var i1 := mb.vert(b.x, y, b.y, UP, col, 0.0, -1.0)
	var i2 := mb.vert(c.x, y, c.y, UP, col, 0.0, -1.0)
	var i3 := mb.vert(d.x, y, d.y, UP, col, 0.0, -1.0)
	mb.tri(i0, i1, i2, UP)
	mb.tri(i0, i2, i3, UP)


## a building: walls get window UVs (u = metres along the wall, v = metres of height), the roof is flat (v = -1)
static func building(walls: MB, b: Dictionary) -> void:
	var P: PackedVector2Array = b["pts"]
	var n := P.size()
	var hg: float = b["h"]
	var col: Color = b["col"]
	var cum := 0.0
	for i in n:
		var p := P[i]
		var q := P[(i + 1) % n]
		var d := q - p
		var l := d.length()
		if l < 0.05:
			continue
		var nrm := Vector3(d.y / l, 0.0, -d.x / l)
		var sh := 0.9 + 0.1 * absf(nrm.x)
		var cc := Color(col.r * sh, col.g * sh, col.b * sh, 1.0)
		var i0 := walls.vert(p.x, 0.0, p.y, nrm, cc, cum, 0.0)
		var i1 := walls.vert(q.x, 0.0, q.y, nrm, cc, cum + l, 0.0)
		var i2 := walls.vert(p.x, hg, p.y, nrm, cc, cum, hg)
		var i3 := walls.vert(q.x, hg, q.y, nrm, cc, cum + l, hg)
		walls.tri(i0, i1, i3, nrm)
		walls.tri(i0, i3, i2, nrm)
		cum += l
	fill_poly(walls, P, hg + 0.02, b["roof"])


static func join_rings(ways: Array) -> Array:
	var pool: Array = []
	for w in ways:
		pool.append(w.duplicate())
	var rings: Array = []
	while pool.size() > 0:
		var cur: Array = pool.pop_back()
		var guard := 0
		while cur[0] != cur[cur.size() - 1] and guard <= pool.size() + 2:
			guard += 1
			var found := -1
			var rev := false
			var end: Vector2 = cur[cur.size() - 1]
			for i in pool.size():
				var w: Array = pool[i]
				if w[0] == end:
					found = i
					break
				if w[w.size() - 1] == end:
					found = i
					rev = true
					break
			if found < 0:
				break
			var w2: Array = pool[found]
			pool.remove_at(found)
			if rev:
				w2.reverse()
			cur = cur + w2.slice(1)
		if cur.size() >= 4 and cur[0] == cur[cur.size() - 1]:
			rings.append(cur)
	return rings


# ------------------------------------------------------------------ one cell
static func process(ci: int, cj: int, text: String) -> Dictionary:
	var res := {"ci": ci, "cj": cj, "ok": false}
	var parsed: Variant = JSON.parse_string(text)
	if not (parsed is Dictionary) or not parsed.has("elements"):
		return res
	var els: Array = parsed["elements"]
	var cen := Geo.proj((cj + 0.5) * CELL, (ci + 0.5) * CELL)
	var ax := cen.x
	var az := cen.y
	var roads: Array = []
	var blds: Array = []
	var areas: Array = []
	var water: Array = []
	var wlines: Array = []
	var coast: Array = []
	var solids: Array = []
	var bigs: Array = []
	for e in els:
		var et: String = str(e.get("type", ""))
		var t: Dictionary = e.get("tags", {})
		var id: int = int(e.get("id", 0))
		if et == "relation":
			var st := area_style(t)
			if st.is_empty() or st[0] != "water" or not e.has("members"):
				continue
			var outs: Array = []
			var ins: Array = []
			for m in e["members"]:
				if str(m.get("type", "")) != "way" or not m.has("geometry"):
					continue
				var arr: Array = []
				for q in m["geometry"]:
					if q != null:
						arr.append(Vector2(q["lat"], q["lon"]))
				if arr.size() < 2:
					continue
				if str(m.get("role", "")) == "inner":
					ins.append(arr)
				else:
					outs.append(arr)
			var rings := join_rings(outs)
			var holes := join_rings(ins)
			var k := 0
			for r in rings:
				var pr := PackedVector2Array()
				for q in r:
					pr.append(Geo.proj(q.x, q.y))
				pr = clean_ring(Geo.simplify(pr, 2.5))
				if pr.size() >= 3:
					var hs: Array = []
					for hr in holes:
						var ph := PackedVector2Array()
						for q in hr:
							ph.append(Geo.proj(q.x, q.y))
						ph = clean_ring(Geo.simplify(ph, 2.5))
						if ph.size() >= 3 and Geometry2D.is_point_in_polygon(ph[0], pr):
							hs.append(ph)
					bigs.append({"key": "r%d_%d" % [id, k], "pts": pr, "holes": hs, "kind": "water", "col": st[1], "layer": st[2]})
				k += 1
			continue
		if et != "way" or not e.has("geometry"):
			continue
		var g: Array = []
		for q in e["geometry"]:
			if q != null:
				g.append(q)
		if g.size() < 2:
			continue
		var hwv: String = str(t.get("highway", ""))
		if hwv != "" and HW.has(hwv) and str(t.get("area", "")) != "yes" and str(t.get("service", "")) != "parking_aisle":
			if str(t.get("tunnel", "")) == "yes":
				continue
			var def: Array = HW[hwv]
			var ow := oneway_of(t)
			var w := road_width(t, def, ow)
			var rev := ow == -1
			var y := 0.2 + int(def[1]) * 0.015 + (id % 5) * 0.002 + (0.05 if t.has("bridge") else 0.0)
			var cur: PackedVector2Array = PackedVector2Array()
			var frags: Array = []
			for i in g.size() - 1:
				var a: Dictionary = g[i]
				var b: Dictionary = g[i + 1]
				if in_cell(ci, cj, (a["lat"] + b["lat"]) / 2.0, (a["lon"] + b["lon"]) / 2.0):
					if cur.size() == 0:
						cur = PackedVector2Array([Geo.proj(a["lat"], a["lon"])])
						frags.append(cur)
					cur.append(Geo.proj(b["lat"], b["lon"]))
					frags[frags.size() - 1] = cur
				else:
					cur = PackedVector2Array()
			for fp in frags:
				var pp: PackedVector2Array = fp
				if rev:
					pp.reverse()
				roads.append({"pts": pp, "w": w, "rank": def[1], "ow": 1 if ow != 0 else 0, "name": str(t.get("name:ar", t.get("name", ""))),
					"ref": str(t.get("ref", "")), "cls": hwv, "y": y, "id": id})
			continue
		var bv: String = str(t.get("building", ""))
		if bv != "" and bv != "no":
			if g.size() < 4:
				continue
			var la0 := 90.0
			var la1 := -90.0
			var lo0 := 180.0
			var lo1 := -180.0
			for q in g:
				la0 = minf(la0, q["lat"])
				la1 = maxf(la1, q["lat"])
				lo0 = minf(lo0, q["lon"])
				lo1 = maxf(lo1, q["lon"])
			if not in_cell(ci, cj, (la0 + la1) / 2.0, (lo0 + lo1) / 2.0):
				continue
			var pts := PackedVector2Array()
			for q in g:
				pts.append(Geo.proj(q["lat"], q["lon"]))
			pts = clean_ring(pts)
			if pts.size() < 3:
				continue
			var ar := Geo.poly_area(pts)
			if absf(ar) < 6.0:
				continue
			if ar < 0.0:
				pts.reverse()
			var col := Geo.lin("#f2ece0") if bv == "mosque" else Geo.lin(BCOL[int(Geo.hash3(id, 5, 9) * BCOL.size())])
			var roof := Geo.lin(BROOF[int(Geo.hash3(id, 6, 9) * BROOF.size())])
			blds.append({"pts": pts, "h": bld_height(t, id), "col": col, "roof": roof, "id": id})
			solids.append({"pts": pts, "closed": true, "kind": "bld"})
			continue
		if str(t.get("natural", "")) == "coastline":
			var cc: PackedVector2Array = PackedVector2Array()
			for i in g.size() - 1:
				var a: Dictionary = g[i]
				var b: Dictionary = g[i + 1]
				if in_cell(ci, cj, (a["lat"] + b["lat"]) / 2.0, (a["lon"] + b["lon"]) / 2.0):
					if cc.size() == 0:
						cc = PackedVector2Array([Geo.proj(a["lat"], a["lon"])])
						coast.append(cc)
					cc.append(Geo.proj(b["lat"], b["lon"]))
					coast[coast.size() - 1] = cc
				else:
					cc = PackedVector2Array()
			continue
		var wwv: String = str(t.get("waterway", ""))
		if wwv in ["river", "canal", "stream", "drain"]:
			var nm: String = str(t.get("name:ar", t.get("name", "")))
			var wt := str(t.get("width", "")).to_float()
			var ww := wt
			if not (wt > 0.0):
				if wwv == "river":
					ww = 160.0 if ("نيل" in nm or "nile" in nm.to_lower() or "nile" in str(t.get("name:en", "")).to_lower()) else 22.0
				elif wwv == "canal":
					ww = 9.0
				else:
					ww = 4.0
			ww = minf(300.0, ww)
			var cw: PackedVector2Array = PackedVector2Array()
			for i in g.size() - 1:
				var a: Dictionary = g[i]
				var b: Dictionary = g[i + 1]
				if in_cell(ci, cj, (a["lat"] + b["lat"]) / 2.0, (a["lon"] + b["lon"]) / 2.0):
					if cw.size() == 0:
						cw = PackedVector2Array([Geo.proj(a["lat"], a["lon"])])
						wlines.append({"w": ww, "pts": cw})
					cw.append(Geo.proj(b["lat"], b["lon"]))
					wlines[wlines.size() - 1]["pts"] = cw
				else:
					cw = PackedVector2Array()
			continue
		var st2 := area_style(t)
		if st2.is_empty() or g.size() < 4:
			continue
		var f0: Dictionary = g[0]
		var fl: Dictionary = g[g.size() - 1]
		if f0["lat"] != fl["lat"] or f0["lon"] != fl["lon"]:
			continue
		var a_la0 := 90.0
		var a_la1 := -90.0
		var a_lo0 := 180.0
		var a_lo1 := -180.0
		for q in g:
			a_la0 = minf(a_la0, q["lat"])
			a_la1 = maxf(a_la1, q["lat"])
			a_lo0 = minf(a_lo0, q["lon"])
			a_lo1 = maxf(a_lo1, q["lon"])
		var ext := maxf((a_lo1 - a_lo0) * Geo.kx, (a_la1 - a_la0) * Geo.KY)
		var ap := PackedVector2Array()
		for i in g.size() - 1:
			ap.append(Geo.proj(g[i]["lat"], g[i]["lon"]))
		if ext > 700.0:
			ap = clean_ring(Geo.simplify(ap, 2.5))
			if ap.size() >= 3:
				bigs.append({"key": "w%d" % id, "pts": ap, "holes": [], "kind": st2[0], "col": st2[1], "layer": st2[2]})
			continue
		if not in_cell(ci, cj, (a_la0 + a_la1) / 2.0, (a_lo0 + a_lo1) / 2.0):
			continue
		ap = clean_ring(ap)
		if ap.size() < 3 or absf(Geo.poly_area(ap)) < 30.0:
			continue
		var o := {"pts": ap, "col": st2[1], "layer": st2[2]}
		if st2[0] == "water":
			water.append(o)
			if absf(Geo.poly_area(ap)) > 400.0:
				var closed := ap.duplicate()
				closed.append(ap[0])
				solids.append({"pts": closed, "closed": false, "kind": "water"})
		else:
			areas.append(o)

	# ---- meshes (vertex positions are relative to the cell centre)
	var flat := MB.new(ax, az)
	var rd := MB.new(ax, az)
	var bw := MB.new(ax, az)
	for o in areas:
		fill_poly(flat, o["pts"], 0.03 + int(o["layer"]) * 0.03, Geo.lin(o["col"]))
	for o in water:
		fill_poly(flat, o["pts"], 0.12, Geo.lin(o["col"]))
	var sea := Geo.lin("#2a7fb0")
	for cs in coast:
		var cp: PackedVector2Array = cs
		for i in cp.size() - 1:
			var a := cp[i]
			var b := cp[i + 1]
			var d := b - a
			var l := d.length()
			if l < 0.01:
				continue
			var nv := Vector2(-d.y / l, d.x / l) * SEA_W   # the water is on the right of a coastline way
			quad_up(flat, a, b, b + nv, a + nv, 0.13, sea)
	for wl in wlines:
		ribbon(flat, wl["pts"], wl["w"], 0.125, Geo.lin("#2f86b5"), 0.0)
	for f in roads:
		var cls: String = f["cls"]
		var mark := 0.0 if (cls == "track" or float(f["w"]) < 5.0) else 1.0
		ribbon(rd, f["pts"], f["w"], f["y"], road_color(int(f["rank"]), cls), mark)
	for b in blds:
		building(bw, b)
	res["ok"] = true
	res["ax"] = ax
	res["az"] = az
	res["roads"] = roads
	res["solids"] = solids
	res["n_blds"] = blds.size()
	res["flat"] = [] if flat.is_empty() else flat.arrays()
	res["rd"] = [] if rd.is_empty() else rd.arrays()
	res["bw"] = [] if bw.is_empty() else bw.arrays()
	# big areas get their own mesh (built once, shared by every cell that touches them)
	var bout: Array = []
	for b in bigs:
		var bb := ring_box(b["pts"])
		var cx := bb.position.x + bb.size.x / 2.0
		var cz := bb.position.y + bb.size.y / 2.0
		var mb := MB.new(cx, cz)
		var is_w: bool = b["kind"] == "water"
		fill_poly(mb, b["pts"], 0.11 if is_w else 0.03 + int(b["layer"]) * 0.03, Geo.lin(b["col"]))
		for hp in b["holes"]:
			fill_poly(mb, hp, 0.125 if is_w else 0.035, Geo.lin("#d4c39a"))
		var walls: Array = []
		if is_w and absf(Geo.poly_area(b["pts"])) > 1500.0:
			var closed2: PackedVector2Array = (b["pts"] as PackedVector2Array).duplicate()
			closed2.append(b["pts"][0])
			walls.append(closed2)
		bout.append({"key": b["key"], "ax": cx, "az": cz, "arrays": [] if mb.is_empty() else mb.arrays(), "walls": walls})
	res["bigs"] = bout
	return res
